#!/usr/bin/env python3
"""福满楼中餐馆网站 + 在线订台服务。

仅使用 Python 3 标准库 + SQLite。
"""
import json
import os
import re
import secrets
import sqlite3
import sys
import threading
from datetime import date, datetime, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(BASE_DIR, "static")

SLOT_START = 11 * 60          # 11:00
SLOT_END = 21 * 60            # 21:00 (last slot)
SLOT_STEP = 30
SLOT_CAPACITY = 20            # 每个时段 20 个座位
MAX_PARTY = 8
BOOKING_WINDOW_DAYS = 60

PHONE_RE = re.compile(r"^[0-9+\-\s()]{6,20}$")
DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
TIME_RE = re.compile(r"^([01]\d|2[0-3]):([0-5]\d)$")


def data_dir():
    d = os.environ.get("MOBILELLM_DATA_DIR")
    if not d:
        d = os.path.join(BASE_DIR, "data")
    os.makedirs(d, exist_ok=True)
    return d


def db_path():
    return os.environ.get("RESERVATION_DB") or os.path.join(data_dir(), "reservations.db")


def connect():
    conn = sqlite3.connect(db_path(), timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA busy_timeout = 10000")
    return conn


def init_db():
    with connect() as conn:
        conn.execute("PRAGMA journal_mode = WAL")
        conn.execute(
            """CREATE TABLE IF NOT EXISTS reservations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                code TEXT NOT NULL UNIQUE,
                name TEXT NOT NULL,
                phone TEXT NOT NULL,
                date TEXT NOT NULL,
                time TEXT NOT NULL,
                party_size INTEGER NOT NULL,
                created_at TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'confirmed'
            )"""
        )
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_res_date_time ON reservations(date, time)"
        )


def all_slots():
    slots = []
    m = SLOT_START
    while m <= SLOT_END:
        slots.append("%02d:%02d" % (m // 60, m % 60))
        m += SLOT_STEP
    return slots


SLOTS = all_slots()


def parse_date(s):
    if not isinstance(s, str) or not DATE_RE.match(s):
        return None
    try:
        return datetime.strptime(s, "%Y-%m-%d").date()
    except ValueError:
        return None


def date_range_error(d):
    today = date.today()
    if d < today:
        return "不能预订过去的日期"
    if d > today + timedelta(days=BOOKING_WINDOW_DAYS):
        return "只能预订未来 %d 天内的日期" % BOOKING_WINDOW_DAYS
    return None


def booked_seats(conn, d, t):
    row = conn.execute(
        "SELECT COALESCE(SUM(party_size), 0) AS s FROM reservations "
        "WHERE date = ? AND time = ? AND status = 'confirmed'",
        (d, t),
    ).fetchone()
    return int(row["s"])


def availability(d):
    with connect() as conn:
        rows = conn.execute(
            "SELECT time, COALESCE(SUM(party_size), 0) AS s FROM reservations "
            "WHERE date = ? AND status = 'confirmed' GROUP BY time",
            (d,),
        ).fetchall()
    used = {r["time"]: int(r["s"]) for r in rows}
    out = []
    for t in SLOTS:
        b = used.get(t, 0)
        out.append({
            "time": t,
            "capacity": SLOT_CAPACITY,
            "booked": b,
            "remaining": max(0, SLOT_CAPACITY - b),
            "available": SLOT_CAPACITY - b > 0,
        })
    return out


def new_code(conn):
    for _ in range(20):
        code = "FML-" + secrets.token_hex(3).upper()
        if not conn.execute("SELECT 1 FROM reservations WHERE code = ?", (code,)).fetchone():
            return code
    raise RuntimeError("无法生成预订编号")


def validate_booking(data):
    """返回 (cleaned, errors)。errors 为中文消息列表。"""
    errors = []
    if not isinstance(data, dict):
        return None, ["请求内容必须是 JSON 对象"]
    name = data.get("name")
    name = name.strip() if isinstance(name, str) else ""
    if not name:
        errors.append("请填写姓名")
    elif len(name) > 40:
        errors.append("姓名不能超过 40 个字符")

    phone = data.get("phone")
    phone = phone.strip() if isinstance(phone, str) else ""
    if not phone:
        errors.append("请填写联系电话")
    elif not PHONE_RE.match(phone):
        errors.append("联系电话格式不正确（6-20 位数字，可含 + - 空格 括号）")

    d = parse_date(data.get("date"))
    if d is None:
        errors.append("日期格式应为 YYYY-MM-DD")
    else:
        err = date_range_error(d)
        if err:
            errors.append(err)

    t = data.get("time")
    if not isinstance(t, str) or not TIME_RE.match(t) or t not in SLOTS:
        errors.append("用餐时间需在 11:00 至 21:00 之间，且为 30 分钟整点时段")

    ps = data.get("party_size")
    if isinstance(ps, bool):
        ps = None
    if isinstance(ps, str) and ps.strip().isdigit():
        ps = int(ps.strip())
    if not isinstance(ps, int):
        errors.append("请选择用餐人数")
    elif ps < 1 or ps > MAX_PARTY:
        errors.append("用餐人数需在 1 至 %d 人之间" % MAX_PARTY)

    if errors:
        return None, errors
    return {"name": name, "phone": phone, "date": d.isoformat(), "time": t, "party_size": ps}, []


class BookingError(Exception):
    def __init__(self, status, message):
        super().__init__(message)
        self.status = status
        self.message = message


_insert_lock = threading.Lock()


def create_reservation(data):
    cleaned, errors = validate_booking(data)
    if errors:
        raise BookingError(400, "；".join(errors))
    with _insert_lock:
        conn = connect()
        try:
            conn.execute("BEGIN IMMEDIATE")
            used = booked_seats(conn, cleaned["date"], cleaned["time"])
            if used + cleaned["party_size"] > SLOT_CAPACITY:
                conn.rollback()
                raise BookingError(
                    409,
                    "抱歉，%s %s 时段座位不足（剩余 %d 个座位，您需要 %d 个）"
                    % (cleaned["date"], cleaned["time"], max(0, SLOT_CAPACITY - used), cleaned["party_size"]),
                )
            code = new_code(conn)
            created = datetime.now().isoformat(timespec="seconds")
            cur = conn.execute(
                "INSERT INTO reservations (code, name, phone, date, time, party_size, created_at, status) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, 'confirmed')",
                (code, cleaned["name"], cleaned["phone"], cleaned["date"], cleaned["time"],
                 cleaned["party_size"], created),
            )
            conn.commit()
            rid = cur.lastrowid
        finally:
            conn.close()
    return {
        "id": rid, "code": code, "name": cleaned["name"], "phone": cleaned["phone"],
        "date": cleaned["date"], "time": cleaned["time"], "party_size": cleaned["party_size"],
        "created_at": created, "status": "confirmed",
    }


def get_reservation(code):
    with connect() as conn:
        row = conn.execute("SELECT * FROM reservations WHERE code = ?", (code,)).fetchone()
    return dict(row) if row else None


class Handler(BaseHTTPRequestHandler):
    server_version = "Fumanlou/1.0"

    def log_message(self, fmt, *args):
        sys.stderr.write("%s - %s\n" % (self.address_string(), fmt % args))

    def _send(self, status, body, ctype="application/json; charset=utf-8"):
        if isinstance(body, (dict, list)):
            body = json.dumps(body, ensure_ascii=False).encode("utf-8")
        elif isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _json(self, status, obj):
        self._send(status, obj)

    def _error(self, status, message):
        self._json(status, {"error": message})

    def _static(self, rel):
        path = os.path.normpath(os.path.join(STATIC_DIR, rel))
        if not path.startswith(STATIC_DIR + os.sep) or not os.path.isfile(path):
            self._error(404, "页面不存在")
            return
        ext = os.path.splitext(path)[1].lower()
        ctype = {
            ".html": "text/html; charset=utf-8",
            ".css": "text/css; charset=utf-8",
            ".js": "application/javascript; charset=utf-8",
            ".svg": "image/svg+xml",
            ".png": "image/png",
            ".ico": "image/x-icon",
        }.get(ext, "application/octet-stream")
        with open(path, "rb") as f:
            self._send(200, f.read(), ctype)

    def do_GET(self):
        u = urlparse(self.path)
        path = u.path
        try:
            if path in ("/", "/index.html"):
                return self._static("index.html")
            if path == "/api/health":
                return self._json(200, {"status": "ok"})
            if path == "/api/availability":
                q = parse_qs(u.query)
                d = parse_date((q.get("date") or [""])[0])
                if d is None:
                    return self._error(400, "日期格式应为 YYYY-MM-DD")
                err = date_range_error(d)
                if err:
                    return self._error(400, err)
                return self._json(200, {
                    "date": d.isoformat(),
                    "capacity": SLOT_CAPACITY,
                    "slots": availability(d.isoformat()),
                })
            if path.startswith("/api/reservations/"):
                code = path[len("/api/reservations/"):].strip().upper()
                if not code:
                    return self._error(400, "请提供预订编号")
                row = get_reservation(code)
                if not row:
                    return self._error(404, "未找到该预订编号")
                return self._json(200, row)
            if path.startswith("/api/"):
                return self._error(404, "接口不存在")
            return self._static(path.lstrip("/"))
        except Exception as exc:  # pragma: no cover
            self._error(500, "服务器内部错误：%s" % exc)

    def do_HEAD(self):
        self.do_GET()

    def do_POST(self):
        u = urlparse(self.path)
        if u.path != "/api/reservations":
            return self._error(404, "接口不存在")
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            return self._error(400, "请求长度无效")
        if length > 64 * 1024:
            return self._error(413, "请求内容过大")
        raw = self.rfile.read(length) if length else b""
        try:
            data = json.loads(raw.decode("utf-8")) if raw else None
        except (UnicodeDecodeError, json.JSONDecodeError):
            return self._error(400, "请求内容不是有效的 JSON")
        try:
            booking = create_reservation(data)
        except BookingError as exc:
            return self._error(exc.status, exc.message)
        except Exception as exc:  # pragma: no cover
            return self._error(500, "服务器内部错误：%s" % exc)
        self._json(201, {"message": "订台成功，期待您的光临！", "reservation": booking})


def make_server(port=0, host="0.0.0.0"):
    init_db()
    httpd = ThreadingHTTPServer((host, port), Handler)
    httpd.daemon_threads = True
    return httpd


def main():
    port = int(os.environ.get("PORT", "8000"))
    httpd = make_server(port)
    print("福满楼中餐馆已启动: http://0.0.0.0:%d  (DB: %s)" % (port, db_path()), flush=True)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()


if __name__ == "__main__":
    main()
