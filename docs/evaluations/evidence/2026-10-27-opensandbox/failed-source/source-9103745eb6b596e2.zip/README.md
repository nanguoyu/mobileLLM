# 福满楼中餐馆 · 在线订台网站

一个完整的中餐馆展示 + 在线订台网站，**仅使用 Python 3 标准库 + SQLite**（无第三方依赖）。

## 功能

- 中文响应式单页界面：头图、招牌菜单、关于/营业时间/联系信息、订台表单、实时空位、预订查询。
- 实时空位：每 30 分钟一个时段（11:00–21:00，共 21 个），每个时段容量 **20 座**。
- 在线订台：姓名、电话、日期（今天至未来 60 天）、时间、人数（1–8）。
- 服务端校验：非法输入返回 **400**，座位不足返回 **409**，均为中文错误信息。
- 成功后返回 **201** 与预订编号（如 `FML-1A2B3C`），可凭编号查询。
- 数据持久化在服务端 SQLite，刷新页面或重启服务不丢失；不存在“仅前端”的预订状态。

## 运行

```bash
PORT=8000 python3 app.py
# 打开 http://localhost:8000
```

数据库位置：`$MOBILELLM_DATA_DIR/reservations.db`；若未设置该环境变量，则使用 `./data/reservations.db`（目录自动创建）。
可用 `RESERVATION_DB` 环境变量覆盖完整路径。

## 测试

```bash
python3 -m unittest discover -s tests -v
```

测试会在临时目录创建独立数据库，并在本机随机端口启动真实 HTTP 服务，覆盖：首页与静态资源、空位接口、正常订台与查询、各类非法输入（400）、容量冲突（409）、服务重启后的持久化。

## API

### `GET /api/availability?date=YYYY-MM-DD`

```json
{
  "date": "2026-10-30",
  "capacity": 20,
  "slots": [
    {"time": "11:00", "capacity": 20, "booked": 0, "remaining": 20, "available": true}
  ]
}
```

日期格式错误或超出今天~+60 天范围时返回 400。

### `POST /api/reservations`

```json
{"name": "张伟", "phone": "13800138000", "date": "2026-10-30", "time": "18:30", "party_size": 4}
```

- `201`：
```json
{"message": "订台成功，期待您的光临！", "reservation": {"id": 1, "code": "FML-1A2B3C", "name": "张伟", "phone": "13800138000", "date": "2026-10-30", "time": "18:30", "party_size": 4, "created_at": "2026-10-27T12:00:00", "status": "confirmed"}}
```
- `400`：`{"error": "请填写姓名"}` 等中文提示（多个错误用“；”连接）。
- `409`：`{"error": "抱歉，2026-10-30 18:30 时段座位不足（剩余 0 个座位，您需要 2 个）"}`

### `GET /api/reservations/<code>`

返回预订对象；不存在返回 `404 {"error": "未找到该预订编号"}`。编号不区分大小写。

### `GET /api/health`

`{"status": "ok"}`

## 数据表

```sql
CREATE TABLE reservations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  phone TEXT NOT NULL,
  date TEXT NOT NULL,
  time TEXT NOT NULL,
  party_size INTEGER NOT NULL,
  created_at TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'confirmed'
);
```

并发写入使用进程内互斥锁 + SQLite `BEGIN IMMEDIATE`，避免超卖。

## 文件结构

```
app.py               HTTP 服务 + API + SQLite
static/index.html    页面结构
static/styles.css    样式（响应式）
static/app.js        前端交互（fetch）
tests/test_app.py    集成测试
README.md
```
