"use strict";

const form = document.getElementById("booking-form");
const dateInput = document.getElementById("date");
const timeInput = document.getElementById("time");
const partySelect = document.getElementById("party_size");
const slotsBox = document.getElementById("slots");
const formMessage = document.getElementById("form-message");
const submitBtn = document.getElementById("submit-btn");
const availabilityDate = document.getElementById("availability-date");
const availabilityList = document.getElementById("availability-list");
const confirmation = document.getElementById("confirmation");
const lookupForm = document.getElementById("lookup-form");
const lookupMessage = document.getElementById("lookup-message");

let lastAvailability = null;

function todayISO() {
  const d = new Date();
  const off = d.getTimezoneOffset();
  return new Date(d.getTime() - off * 60000).toISOString().slice(0, 10);
}

function maxISO() {
  const d = new Date();
  d.setDate(d.getDate() + 60);
  const off = d.getTimezoneOffset();
  return new Date(d.getTime() - off * 60000).toISOString().slice(0, 10);
}

function showMessage(el, text, kind) {
  el.textContent = text;
  el.classList.remove("is-error", "is-success");
  el.classList.add(kind === "error" ? "is-error" : "is-success");
  el.hidden = false;
}

function hideMessage(el) {
  el.hidden = true;
  el.textContent = "";
}

async function fetchAvailability(date) {
  slotsBox.innerHTML = '<p class="slots-empty">正在加载空位…</p>';
  try {
    const res = await fetch("/api/availability?date=" + encodeURIComponent(date), {
      headers: { Accept: "application/json" },
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "无法获取空位");
    lastAvailability = data;
    renderSlots(data.slots);
    renderAvailabilityList(data);
  } catch (err) {
    lastAvailability = null;
    slotsBox.innerHTML = '<p class="slots-empty">' + err.message + "</p>";
    availabilityList.innerHTML = '<p class="muted">' + err.message + "</p>";
  }
}

function renderSlots(slots) {
  slotsBox.innerHTML = "";
  const party = parseInt(partySelect.value || "1", 10) || 1;
  slots.forEach((slot) => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "slot";
    btn.dataset.time = slot.time;
    btn.setAttribute("aria-pressed", timeInput.value === slot.time ? "true" : "false");
    const enough = slot.remaining >= party;
    btn.disabled = !enough;
    btn.innerHTML = slot.time + "<small>" + (slot.remaining > 0 ? "剩 " + slot.remaining + " 位" : "已满") + "</small>";
    if (!enough && slot.remaining > 0) {
      btn.title = "剩余座位不足 " + party + " 人";
    }
    btn.addEventListener("click", () => {
      timeInput.value = slot.time;
      slotsBox.querySelectorAll(".slot").forEach((b) => b.setAttribute("aria-pressed", "false"));
      btn.setAttribute("aria-pressed", "true");
      hideMessage(formMessage);
    });
    slotsBox.appendChild(btn);
  });
  if (!slots.length) {
    slotsBox.innerHTML = '<p class="slots-empty">该日期暂无可订时段</p>';
  }
  if (timeInput.value && !slots.some((s) => s.time === timeInput.value && s.remaining > 0)) {
    timeInput.value = "";
  }
}

function renderAvailabilityList(data) {
  availabilityDate.textContent = data.date + " · 每时段 " + data.capacity + " 座";
  availabilityList.innerHTML = "";
  data.slots.forEach((slot) => {
    const row = document.createElement("div");
    row.className = "availability-row" + (slot.remaining === 0 ? " is-full" : "");
    const label = document.createElement("span");
    label.textContent = slot.time;
    const seats = document.createElement("span");
    seats.className = "seats" + (slot.remaining > 0 && slot.remaining <= 4 ? " low" : "");
    seats.textContent = slot.remaining === 0 ? "已满" : "剩 " + slot.remaining + " 位";
    row.append(label, seats);
    availabilityList.appendChild(row);
  });
}

function showConfirmation(r) {
  document.getElementById("conf-code").textContent = r.code;
  document.getElementById("conf-name").textContent = r.name;
  document.getElementById("conf-date").textContent = r.date;
  document.getElementById("conf-time").textContent = r.time;
  document.getElementById("conf-party").textContent = r.party_size + " 人";
  confirmation.hidden = false;
  confirmation.scrollIntoView({ behavior: "smooth", block: "nearest" });
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  hideMessage(formMessage);

  if (!timeInput.value) {
    showMessage(formMessage, "请选择用餐时间", "error");
    return;
  }
  const payload = {
    name: document.getElementById("name").value.trim(),
    phone: document.getElementById("phone").value.trim(),
    date: dateInput.value,
    time: timeInput.value,
    party_size: parseInt(partySelect.value || "0", 10),
  };

  submitBtn.disabled = true;
  submitBtn.textContent = "提交中…";
  try {
    const res = await fetch("/api/reservations", {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "订台失败，请稍后再试");
    showMessage(formMessage, data.message + " 预订编号：" + data.reservation.code, "success");
    showConfirmation(data.reservation);
    form.reset();
    timeInput.value = "";
    await fetchAvailability(payload.date);
  } catch (err) {
    showMessage(formMessage, err.message, "error");
    if (payload.date) await fetchAvailability(payload.date);
  } finally {
    submitBtn.disabled = false;
    submitBtn.textContent = "确认订台";
  }
});

dateInput.addEventListener("change", () => {
  hideMessage(formMessage);
  timeInput.value = "";
  if (dateInput.value) fetchAvailability(dateInput.value);
});

partySelect.addEventListener("change", () => {
  if (lastAvailability) renderSlots(lastAvailability.slots);
});

lookupForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  hideMessage(lookupMessage);
  const code = document.getElementById("lookup-code").value.trim().toUpperCase();
  if (!code) {
    showMessage(lookupMessage, "请输入预订编号", "error");
    return;
  }
  try {
    const res = await fetch("/api/reservations/" + encodeURIComponent(code));
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "查询失败");
    showMessage(
      lookupMessage,
      data.name + " · " + data.date + " " + data.time + " · " + data.party_size + " 人 · 状态：" +
        (data.status === "confirmed" ? "已确认" : data.status),
      "success"
    );
  } catch (err) {
    showMessage(lookupMessage, err.message, "error");
  }
});

// 初始化
dateInput.min = todayISO();
dateInput.max = maxISO();
dateInput.value = todayISO();
fetchAvailability(dateInput.value);
