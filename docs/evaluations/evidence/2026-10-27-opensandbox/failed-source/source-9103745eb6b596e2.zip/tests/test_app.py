import json
import os
import sys
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from datetime import date, timedelta

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, BASE)

import app  # noqa: E402


def free_date(days=3):
    return (date.today() + timedelta(days=days)).isoformat()


class ServerTestCase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        os.environ["MOBILELLM_DATA_DIR"] = self.tmp.name
        os.environ["RESERVATION_DB"] = os.path.join(self.tmp.name, "reservations.db")
        self.httpd = app.make_server(0, "127.0.0.1")
        self.port = self.httpd.server_address[1]
        self.base = "http://127.0.0.1:%d" % self.port
        self.thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)
        self.thread.start()

    def tearDown(self):
        self.httpd.shutdown()
        self.httpd.server_close()
        self.thread.join(timeout=5)
        self.tmp.cleanup()
        os.environ.pop("RESERVATION_DB", None)

    def get(self, path):
        try:
            with urllib.request.urlopen(self.base + path, timeout=5) as r:
                return r.status, json.loads(r.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            return e.code, json.loads(e.read().decode("utf-8"))

    def post(self, path, payload):
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(self.base + path, data=data, method="POST",
                                     headers={"Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=5) as r:
                return r.status, json.loads(r.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            return e.code, json.loads(e.read().decode("utf-8"))

    def booking(self, **over):
        payload = {"name": "张伟", "phone": "13800138000", "date": free_date(),
                   "time": "18:30", "party_size": 4}
        payload.update(over)
        return payload

    # ---------- 页面 ----------
    def test_home_page_served(self):
        with urllib.request.urlopen(self.base + "/", timeout=5) as r:
            body = r.read().decode("utf-8")
            self.assertEqual(r.status, 200)
            self.assertIn("text/html", r.headers.get("Content-Type", ""))
        self.assertIn("福满楼", body)
        self.assertIn("在线订台", body)
        self.assertIn("app.js", body)

    def test_static_assets(self):
        for path, needle in (("/styles.css", "--red"), ("/app.js", "/api/reservations")):
            with urllib.request.urlopen(self.base + path, timeout=5) as r:
                self.assertEqual(r.status, 200)
                self.assertIn(needle, r.read().decode("utf-8"))

    # ---------- 空位 ----------
    def test_availability_slots(self):
        status, data = self.get("/api/availability?date=" + free_date())
        self.assertEqual(status, 200)
        times = [s["time"] for s in data["slots"]]
        self.assertEqual(times[0], "11:00")
        self.assertEqual(times[-1], "21:00")
        self.assertEqual(len(times), 21)
        for s in data["slots"]:
            self.assertEqual(s["remaining"], 20)
            self.assertEqual(s["capacity"], 20)
            self.assertTrue(s["available"])

    def test_availability_bad_date(self):
        status, data = self.get("/api/availability?date=2026/01/01")
        self.assertEqual(status, 400)
        self.assertIn("日期", data["error"])
        status, data = self.get("/api/availability")
        self.assertEqual(status, 400)

    def test_availability_past_and_far_future_rejected(self):
        past = (date.today() - timedelta(days=1)).isoformat()
        far = (date.today() + timedelta(days=61)).isoformat()
        self.assertEqual(self.get("/api/availability?date=" + past)[0], 400)
        self.assertEqual(self.get("/api/availability?date=" + far)[0], 400)

    # ---------- 正常订台 ----------
    def test_create_booking_and_fetch(self):
        status, data = self.post("/api/reservations", self.booking())
        self.assertEqual(status, 201)
        r = data["reservation"]
        self.assertTrue(r["code"].startswith("FML-"))
        self.assertEqual(r["status"], "confirmed")
        self.assertEqual(r["party_size"], 4)
        self.assertIn("订台成功", data["message"])

        status, got = self.get("/api/reservations/" + r["code"])
        self.assertEqual(status, 200)
        self.assertEqual(got["name"], "张伟")
        self.assertEqual(got["time"], "18:30")

        status, av = self.get("/api/availability?date=" + r["date"])
        slot = [s for s in av["slots"] if s["time"] == "18:30"][0]
        self.assertEqual(slot["remaining"], 16)
        self.assertEqual(slot["booked"], 4)

    def test_lookup_missing_code_404(self):
        status, data = self.get("/api/reservations/FML-NOPE00")
        self.assertEqual(status, 404)
        self.assertIn("未找到", data["error"])

    # ---------- 参数校验 ----------
    def test_invalid_inputs(self):
        cases = [
            (self.booking(name=""), "姓名"),
            (self.booking(phone="abc"), "电话"),
            (self.booking(date="2020-01-01"), "过去"),
            (self.booking(date=(date.today() + timedelta(days=61)).isoformat()), "60"),
            (self.booking(time="22:00"), "时间"),
            (self.booking(time="18:15"), "时间"),
            (self.booking(party_size=0), "人数"),
            (self.booking(party_size=9), "人数"),
            (self.booking(party_size="x"), "人数"),
            (self.booking(date="not-a-date"), "日期"),
        ]
        for payload, keyword in cases:
            status, data = self.post("/api/reservations", payload)
            self.assertEqual(status, 400, payload)
            self.assertIn(keyword, data["error"], payload)

    def test_invalid_json_400(self):
        req = urllib.request.Request(self.base + "/api/reservations", data=b"{oops", method="POST",
                                     headers={"Content-Type": "application/json"})
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            urllib.request.urlopen(req, timeout=5)
        self.assertEqual(ctx.exception.code, 400)
        body = json.loads(ctx.exception.read().decode("utf-8"))
        self.assertIn("JSON", body["error"])

    # ---------- 容量冲突 ----------
    def test_capacity_conflict_409(self):
        d = free_date(5)
        self.assertEqual(self.post("/api/reservations", self.booking(date=d, time="19:00", party_size=8))[0], 201)
        self.assertEqual(self.post("/api/reservations", self.booking(date=d, time="19:00", party_size=8))[0], 201)
        self.assertEqual(self.post("/api/reservations", self.booking(date=d, time="19:00", party_size=4))[0], 201)
        status, av = self.get("/api/availability?date=" + d)
        slot = [s for s in av["slots"] if s["time"] == "19:00"][0]
        self.assertEqual(slot["remaining"], 0)
        self.assertFalse(slot["available"])

        status, data = self.post("/api/reservations", self.booking(date=d, time="19:00", party_size=1))
        self.assertEqual(status, 409)
        self.assertIn("座位不足", data["error"])

        # 未超出容量的相邻时段仍可预订
        self.assertEqual(self.post("/api/reservations", self.booking(date=d, time="19:30", party_size=8))[0], 201)

    def test_partial_overshoot_rejected(self):
        d = free_date(7)
        self.assertEqual(self.post("/api/reservations", self.booking(date=d, time="12:00", party_size=8))[0], 201)
        self.assertEqual(self.post("/api/reservations", self.booking(date=d, time="12:00", party_size=8))[0], 201)
        status, data = self.post("/api/reservations", self.booking(date=d, time="12:00", party_size=8))
        self.assertEqual(status, 409)
        status, av = self.get("/api/availability?date=" + d)
        self.assertEqual([s for s in av["slots"] if s["time"] == "12:00"][0]["remaining"], 4)

    # ---------- 持久化 ----------
    def test_persistence_across_restart(self):
        status, data = self.post("/api/reservations", self.booking(date=free_date(10), time="20:00"))
        self.assertEqual(status, 201)
        code = data["reservation"]["code"]
        db_file = os.environ["RESERVATION_DB"]

        self.httpd.shutdown()
        self.httpd.server_close()
        self.thread.join(timeout=5)
        self.assertTrue(os.path.isfile(db_file))

        self.httpd = app.make_server(0, "127.0.0.1")
        self.port = self.httpd.server_address[1]
        self.base = "http://127.0.0.1:%d" % self.port
        self.thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)
        self.thread.start()

        status, got = self.get("/api/reservations/" + code)
        self.assertEqual(status, 200)
        self.assertEqual(got["code"], code)
        self.assertEqual(got["date"], free_date(10))

        import sqlite3
        with sqlite3.connect(db_file) as conn:
            count = conn.execute("SELECT COUNT(*) FROM reservations").fetchone()[0]
        self.assertEqual(count, 1)


if __name__ == "__main__":
    unittest.main()
