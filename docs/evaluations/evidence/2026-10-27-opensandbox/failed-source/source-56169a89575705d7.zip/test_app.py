import datetime
import os
import sqlite3
import sys

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)

DATA_DIR = os.environ.get("MOBILELLM_DATA_DIR", os.path.join(BASE_DIR, "data"))
os.makedirs(DATA_DIR, exist_ok=True)
TEST_DB = os.path.join(DATA_DIR, "test_restaurant.db")
if os.path.exists(TEST_DB):
    os.remove(TEST_DB)

from app import create_app, SLOT_CAPACITY, TIME_SLOTS  # noqa: E402

app = create_app(db_path=TEST_DB)
app.config["TESTING"] = True
client = app.test_client()

PASSED = 0


def check(condition, message):
    global PASSED
    assert condition, message
    PASSED += 1
    print("PASS: " + message)


def future(days):
    return (datetime.date.today() + datetime.timedelta(days=days)).isoformat()


# 1. Home page
resp = client.get("/")
html = resp.get_data(as_text=True)
check(resp.status_code == 200, "home page returns 200")
check("福满楼中餐馆" in html, "home page shows restaurant name")
check("招牌北京烤鸭" in html, "home page shows menu highlights")
check("营业时间" in html, "home page shows opening hours")
check("在线订台" in html, "home page links to reservation page")

# 2. Successful booking
booking_date = future(3)
resp = client.post(
    "/reserve",
    data={
        "name": "张伟",
        "phone": "13800138000",
        "date": booking_date,
        "time_slot": "18:00",
        "party_size": "4",
        "notes": "靠窗座位",
    },
    follow_redirects=True,
)
html = resp.get_data(as_text=True)
check(resp.status_code == 200, "successful booking returns 200")
check("预订成功" in html, "confirmation page shows 预订成功")
check("预订编号" in html, "confirmation page shows reservation ID label")
check("张伟" in html and booking_date in html, "confirmation page shows booking details")
with sqlite3.connect(TEST_DB) as conn:
    count = conn.execute("SELECT COUNT(*) FROM reservations").fetchone()[0]
check(count == 1, "successful booking persisted to SQLite")

# 3. Validation rejections
resp = client.post(
    "/reserve",
    data={"name": "", "phone": "13800138000", "date": future(4), "time_slot": "18:00", "party_size": "2"},
)
html = resp.get_data(as_text=True)
check(resp.status_code == 400 and "请填写姓名" in html, "missing name rejected with 400")

resp = client.post(
    "/reserve",
    data={"name": "李娜", "phone": "13800138000", "date": future(4), "time_slot": "18:00", "party_size": "25"},
)
html = resp.get_data(as_text=True)
check(resp.status_code == 400 and "1 至 20 人之间" in html, "party size 25 rejected with 400")

resp = client.post(
    "/reserve",
    data={"name": "李娜", "phone": "13800138000", "date": future(-1), "time_slot": "18:00", "party_size": "2"},
)
html = resp.get_data(as_text=True)
check(resp.status_code == 400 and "不能早于今天" in html, "past date rejected with 400")

resp = client.post(
    "/reserve",
    data={"name": "李娜", "phone": "13800138000", "date": future(4), "time_slot": "03:00", "party_size": "2"},
)
html = resp.get_data(as_text=True)
check(resp.status_code == 400 and "有效的用餐时段" in html, "invalid time slot rejected with 400")

resp = client.post(
    "/reserve",
    data={"name": "李娜", "phone": "abc", "date": future(4), "time_slot": "18:00", "party_size": "2"},
)
html = resp.get_data(as_text=True)
check(resp.status_code == 400 and "有效的联系电话" in html, "invalid phone rejected with 400")

with sqlite3.connect(TEST_DB) as conn:
    count = conn.execute("SELECT COUNT(*) FROM reservations").fetchone()[0]
check(count == 1, "validation failures did not persist any row")

# 4. Capacity / overbooking rejection
capacity_date = future(5)
resp = client.post(
    "/reserve",
    data={"name": "王强", "phone": "13900139000", "date": capacity_date, "time_slot": "19:00", "party_size": "20"},
    follow_redirects=True,
)
check(resp.status_code == 200 and "预订成功" in resp.get_data(as_text=True), "full-capacity booking of 20 accepted")

resp = client.post(
    "/reserve",
    data={"name": "赵敏", "phone": "13700137000", "date": capacity_date, "time_slot": "19:00", "party_size": "1"},
)
html = resp.get_data(as_text=True)
check(resp.status_code == 409 and "座位已满" in html, "overbooking rejected with 409 and friendly message")

with sqlite3.connect(TEST_DB) as conn:
    seats = conn.execute(
        "SELECT COALESCE(SUM(party_size), 0) FROM reservations WHERE date = ? AND time_slot = ?",
        (capacity_date, "19:00"),
    ).fetchone()[0]
check(seats == SLOT_CAPACITY, "booked seats never exceed slot capacity of 20")

resp = client.get("/api/availability?date=%s&time=19:00" % capacity_date)
data = resp.get_json()
check(resp.status_code == 200 and data["remaining"] == 0 and data["capacity"] == SLOT_CAPACITY, "availability API reports 0 remaining seats")

# 5. Admin list
resp = client.get("/admin")
html = resp.get_data(as_text=True)
check(resp.status_code == 200, "admin page returns 200")
check("张伟" in html and "王强" in html, "admin page lists existing reservations")
check("R00001" in html, "admin page shows formatted reservation ID")

print("\nALL %d CHECKS PASSED" % PASSED)
