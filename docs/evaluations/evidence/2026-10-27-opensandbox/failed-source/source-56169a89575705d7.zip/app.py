import datetime
import os
import re
import sqlite3

from flask import (
    Flask,
    abort,
    current_app,
    g,
    jsonify,
    redirect,
    render_template,
    request,
    url_for,
)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.environ.get("MOBILELLM_DATA_DIR", os.path.join(BASE_DIR, "data"))
os.makedirs(DATA_DIR, exist_ok=True)
DEFAULT_DB_PATH = os.environ.get("RESTAURANT_DB", os.path.join(DATA_DIR, "restaurant.db"))

RESTAURANT_NAME = "福满楼中餐馆"
SLOT_CAPACITY = 20
MAX_PARTY_SIZE = 20
TIME_SLOTS = [
    "11:30", "12:00", "12:30", "13:00", "13:30",
    "17:30", "18:00", "18:30", "19:00", "19:30", "20:00", "20:30",
]
PHONE_PATTERN = re.compile(r"^[0-9+\-\s]{6,20}$")

MENU_HIGHLIGHTS = [
    {"name": "招牌北京烤鸭", "desc": "果木明炉烤制，皮脆肉嫩，配薄饼、葱丝与甜面酱。", "price": "¥168"},
    {"name": "麻婆豆腐", "desc": "郫县豆瓣与汉源花椒慢烧，麻辣鲜香，下饭首选。", "price": "¥38"},
    {"name": "清蒸东星斑", "desc": "当日鲜活海鱼，姜葱清蒸，原汁原味。", "price": "¥228"},
    {"name": "蟹粉小笼包", "desc": "现包现蒸，皮薄汁多，一笼六只。", "price": "¥32"},
]

OPENING_HOURS = [
    ("周一至周五", "11:00 - 14:30 / 17:00 - 21:30"),
    ("周六、周日", "10:30 - 15:00 / 16:30 - 22:00"),
]

CONTACT = {
    "phone": "010-8888 6666",
    "address": "北京市朝阳区建国路 88 号 福满楼大厦 1 层",
    "email": "booking@fumanlou.example.com",
}


def create_app(db_path=None):
    app = Flask(__name__)
    app.config["DB_PATH"] = db_path or DEFAULT_DB_PATH
    app.config["JSON_AS_ASCII"] = False
    with app.app_context():
        init_db()

    @app.teardown_appcontext
    def close_db(exc):
        db = g.pop("db", None)
        if db is not None:
            db.close()

    @app.context_processor
    def inject_globals():
        return {
            "restaurant_name": RESTAURANT_NAME,
            "time_slots": TIME_SLOTS,
            "capacity": SLOT_CAPACITY,
            "max_party": MAX_PARTY_SIZE,
            "contact": CONTACT,
        }

    @app.get("/")
    def index():
        return render_template(
            "index.html",
            menu=MENU_HIGHLIGHTS,
            hours=OPENING_HOURS,
            today=datetime.date.today().isoformat(),
        )

    @app.route("/reserve", methods=["GET", "POST"])
    def reserve():
        if request.method == "GET":
            return render_template(
                "reserve.html",
                errors={},
                form={"date": datetime.date.today().isoformat(), "party_size": "2", "time_slot": "18:00"},
            )

        form = {
            "name": request.form.get("name", "").strip(),
            "phone": request.form.get("phone", "").strip(),
            "date": request.form.get("date", "").strip(),
            "time_slot": request.form.get("time_slot", "").strip(),
            "party_size": request.form.get("party_size", "").strip(),
            "notes": request.form.get("notes", "").strip(),
        }
        data, errors = validate_booking(form)
        if errors:
            return render_template("reserve.html", errors=errors, form=form), 400

        db = get_db()
        booked = booked_seats(db, data["date"], data["time_slot"])
        remaining = SLOT_CAPACITY - booked
        if data["party_size"] > remaining:
            errors["form"] = (
                "抱歉，该时段座位已满（仅剩 %d 个座位），请选择其他时段或日期。" % max(remaining, 0)
            )
            return render_template("reserve.html", errors=errors, form=form), 409

        cur = db.execute(
            "INSERT INTO reservations (name, phone, date, time_slot, party_size, notes, created_at)"
            " VALUES (?, ?, ?, ?, ?, ?, ?)",
            (
                data["name"],
                data["phone"],
                data["date"],
                data["time_slot"],
                data["party_size"],
                data["notes"],
                datetime.datetime.now().isoformat(timespec="seconds"),
            ),
        )
        db.commit()
        return redirect(url_for("confirmation", reservation_id=cur.lastrowid))

    @app.get("/reservation/<int:reservation_id>")
    def confirmation(reservation_id):
        row = get_db().execute(
            "SELECT * FROM reservations WHERE id = ?", (reservation_id,)
        ).fetchone()
        if row is None:
            abort(404)
        return render_template("confirmation.html", reservation=row, code=reservation_code(row["id"]))

    @app.get("/admin")
    def admin():
        rows = get_db().execute(
            "SELECT * FROM reservations ORDER BY date, time_slot, id"
        ).fetchall()
        return render_template("admin.html", reservations=rows)

    @app.get("/api/availability")
    def availability():
        date_str = request.args.get("date", "").strip()
        slot = request.args.get("time", "").strip()
        try:
            datetime.date.fromisoformat(date_str)
        except ValueError:
            return jsonify({"error": "日期格式应为 YYYY-MM-DD"}), 400
        if slot not in TIME_SLOTS:
            return jsonify({"error": "无效的用餐时段"}), 400
        booked = booked_seats(get_db(), date_str, slot)
        return jsonify(
            {
                "date": date_str,
                "time": slot,
                "capacity": SLOT_CAPACITY,
                "booked": booked,
                "remaining": max(SLOT_CAPACITY - booked, 0),
            }
        )

    @app.get("/api/reservations")
    def reservations_api():
        rows = get_db().execute(
            "SELECT * FROM reservations ORDER BY date, time_slot, id"
        ).fetchall()
        return jsonify([dict(row) for row in rows])

    return app


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(current_app.config["DB_PATH"])
        g.db.row_factory = sqlite3.Row
    return g.db


def init_db():
    get_db().executescript(
        """
        CREATE TABLE IF NOT EXISTS reservations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            phone TEXT NOT NULL,
            date TEXT NOT NULL,
            time_slot TEXT NOT NULL,
            party_size INTEGER NOT NULL,
            notes TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL
        );
        """
    )
    get_db().commit()


def booked_seats(db, date_str, slot):
    row = db.execute(
        "SELECT COALESCE(SUM(party_size), 0) AS seats FROM reservations WHERE date = ? AND time_slot = ?",
        (date_str, slot),
    ).fetchone()
    return int(row["seats"])


def validate_booking(form):
    errors = {}
    data = {}

    name = form.get("name", "")
    if not name:
        errors["name"] = "请填写姓名。"
    elif len(name) > 40:
        errors["name"] = "姓名不能超过 40 个字符。"
    else:
        data["name"] = name

    phone = form.get("phone", "")
    if not phone:
        errors["phone"] = "请填写联系电话。"
    elif not PHONE_PATTERN.match(phone):
        errors["phone"] = "请输入有效的联系电话（6-20 位数字，可含 + - 空格）。"
    else:
        data["phone"] = phone

    date_str = form.get("date", "")
    if not date_str:
        errors["date"] = "请选择用餐日期。"
    else:
        try:
            booking_date = datetime.date.fromisoformat(date_str)
        except ValueError:
            errors["date"] = "日期格式无效，请使用 YYYY-MM-DD。"
        else:
            if booking_date < datetime.date.today():
                errors["date"] = "预订日期不能早于今天。"
            else:
                data["date"] = date_str

    slot = form.get("time_slot", "")
    if not slot:
        errors["time_slot"] = "请选择用餐时段。"
    elif slot not in TIME_SLOTS:
        errors["time_slot"] = "请选择有效的用餐时段。"
    else:
        data["time_slot"] = slot

    party_raw = form.get("party_size", "")
    if not party_raw:
        errors["party_size"] = "请填写用餐人数。"
    else:
        try:
            party = int(party_raw)
        except ValueError:
            errors["party_size"] = "用餐人数必须为整数。"
        else:
            if party < 1 or party > MAX_PARTY_SIZE:
                errors["party_size"] = "用餐人数需在 1 至 20 人之间。"
            else:
                data["party_size"] = party

    notes = form.get("notes", "")
    if len(notes) > 200:
        errors["notes"] = "备注不能超过 200 个字符。"
    else:
        data["notes"] = notes

    return data, errors


def reservation_code(reservation_id):
    return "R%05d" % reservation_id


app = create_app()


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "5000")))
