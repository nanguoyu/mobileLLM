#!/usr/bin/env python3
"""金玉满堂网站端到端测试（仅用标准库）。

覆盖：健康检查、静态资源、创建预订、字段校验、重复预订、时段容量、
查询（正确/错误凭证）、服务重启后持久化。

运行：python3 tests/test_app.py -v
退出码 0 = 全部通过。
"""
import json
import os
import shutil
import signal
import socket
import subprocess
import sys
import tempfile
import time
import unittest
import urllib.error
import urllib.parse
import urllib.request
from datetime import date, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
APP = ROOT / "app.py"


def free_port():
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def http(method, url, payload=None, timeout=10):
    data = None
    headers = {"Accept": "application/json"}
    if payload is not None:
        data = json.dumps(payload).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read()
            ctype = resp.headers.get("Content-Type", "")
            body = json.loads(raw) if "json" in ctype else raw.decode("utf-8", "replace")
            return resp.status, body, dict(resp.headers)
    except urllib.error.HTTPError as exc:
        raw = exc.read()
        ctype = exc.headers.get("Content-Type", "")
        body = json.loads(raw) if "json" in ctype else raw.decode("utf-8", "replace")
        return exc.code, body, dict(exc.headers)


class Server:
    def __init__(self, data_dir):
        self.data_dir = str(data_dir)
        self.port = free_port()
        self.proc = None
        self.base = f"http://127.0.0.1:{self.port}"

    def start(self):
        env = dict(os.environ, MOBILELLM_DATA_DIR=self.data_dir, PYTHONUNBUFFERED="1")
        self.proc = subprocess.Popen(
            [sys.executable, str(APP), "--host", "127.0.0.1", "--port", str(self.port)],
            cwd=str(ROOT), env=env,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
        )
        deadline = time.time() + 20
        while time.time() < deadline:
            if self.proc.poll() is not None:
                out = self.proc.stdout.read() if self.proc.stdout else ""
                raise RuntimeError(f"服务启动失败：\n{out}")
            try:
                status, _, _ = http("GET", self.base + "/api/health", timeout=1)
                if status == 200:
                    return self
            except Exception:
                time.sleep(0.15)
        raise RuntimeError("服务在 20 秒内未就绪")

    def stop(self):
        if not self.proc:
            return
        if self.proc.poll() is None:
            self.proc.send_signal(signal.SIGTERM)
            try:
                self.proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                self.proc.kill()
                self.proc.wait(timeout=10)
        if self.proc.stdout:
            self.proc.stdout.close()
        self.proc = None


class ReservationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        base_tmp = Path(os.environ.get("MOBILELLM_DATA_DIR", tempfile.gettempdir())) / "test_runs"
        base_tmp.mkdir(parents=True, exist_ok=True)
        cls.tmp = Path(tempfile.mkdtemp(prefix="jinyu-test-", dir=str(base_tmp)))
        cls.data_dir = cls.tmp / "data"
        cls.data_dir.mkdir()
        cls.server = Server(cls.data_dir).start()
        cls.base = cls.server.base
        cls.today = date.today()
        cls.day = (cls.today + timedelta(days=3)).isoformat()

    @classmethod
    def tearDownClass(cls):
        cls.server.stop()
        shutil.rmtree(cls.tmp, ignore_errors=True)

    # ---------- 辅助 ----------
    def payload(self, **over):
        body = {"name": "陈小玉", "phone": "13800000001", "date": self.day,
                "time": "18:00", "party_size": 4, "notes": "靠窗，有小孩"}
        body.update(over)
        return body

    def post(self, **over):
        return http("POST", self.base + "/api/reservations", self.payload(**over))

    # ---------- 用例 ----------
    def test_01_health(self):
        status, body, _ = http("GET", self.base + "/api/health")
        self.assertEqual(status, 200)
        self.assertEqual(body["status"], "ok")
        self.assertTrue(Path(body["db"]).is_relative_to(self.data_dir))

    def test_02_homepage_and_assets(self):
        status, html, headers = http("GET", self.base + "/")
        self.assertEqual(status, 200)
        self.assertIn("text/html", headers["Content-Type"])
        for text in ("金玉满堂", "在线订台", "营业时间", "恩宁路", "bookingForm"):
            self.assertIn(text, html)
        for path, needle in (("/styles.css", "--red"), ("/app.js", "/api/reservations")):
            st, body, _ = http("GET", self.base + path)
            self.assertEqual(st, 200, path)
            self.assertIn(needle, body)
        st, _, _ = http("GET", self.base + "/nope.html")
        self.assertEqual(st, 404)

    def test_03_create_and_lookup(self):
        status, body, _ = self.post(phone="13900000002")
        self.assertEqual(status, 201, body)
        rec = body["reservation"]
        self.assertRegex(rec["code"], r"^JY[A-Z0-9]{6}$")
        self.assertEqual(rec["party_size"], 4)
        self.assertEqual(rec["date"], self.day)
        self.assertIn("created_at", rec)

        q = urllib.parse.urlencode({"code": rec["code"], "phone": rec["phone"]})
        status, body, _ = http("GET", self.base + "/api/reservations?" + q)
        self.assertEqual(status, 200)
        self.assertEqual(body["reservation"]["code"], rec["code"])
        self.assertEqual(body["reservation"]["notes"], "靠窗，有小孩")

        # 错误手机号 / 不存在确认码
        q = urllib.parse.urlencode({"code": rec["code"], "phone": "13900000099"})
        status, body, _ = http("GET", self.base + "/api/reservations?" + q)
        self.assertEqual(status, 404)
        q = urllib.parse.urlencode({"code": "JYZZZZZZ", "phone": rec["phone"]})
        self.assertEqual(http("GET", self.base + "/api/reservations?" + q)[0], 404)
        self.assertEqual(http("GET", self.base + "/api/reservations")[0], 400)

    def test_04_validation_failures(self):
        cases = [
            ({"date": (self.today - timedelta(days=1)).isoformat()}, "date"),
            ({"date": ""}, "date"),
            ({"date": "2026-13-40"}, "date"),
            ({"date": (self.today + timedelta(days=400)).isoformat()}, "date"),
            ({"party_size": 0}, "party_size"),
            ({"party_size": 13}, "party_size"),
            ({"party_size": "abc"}, "party_size"),
            ({"party_size": 2.5}, "party_size"),
            ({"phone": "12345"}, "phone"),
            ({"phone": "23800000001"}, "phone"),
            ({"phone": "1380000000a"}, "phone"),
            ({"time": "15:00"}, "time"),
            ({"time": ""}, "time"),
            ({"name": "陈"}, "name"),
            ({"notes": "很" * 201}, "notes"),
        ]
        _, base_slots, _ = http("GET", self.base + "/api/slots?" + urllib.parse.urlencode({"date": self.day}))
        baseline = dict(base_slots["slots"])

        for over, field in cases:
            with self.subTest(over=over):
                kw = {"phone": "13700000001"}
                kw.update(over)
                status, body, _ = self.post(**kw)
                self.assertEqual(status, 422, body)
                self.assertIn(field, body["fields"], body)

        # 非 JSON 请求体
        req = urllib.request.Request(self.base + "/api/reservations", data=b"not-json",
                                     headers={"Content-Type": "application/json"}, method="POST")
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            urllib.request.urlopen(req, timeout=5)
        self.assertEqual(ctx.exception.code, 400)

        # 校验失败不应落库：用 /api/slots 的真实剩余桌数核对
        q = urllib.parse.urlencode({"date": self.day})
        status, body, _ = http("GET", self.base + "/api/slots?" + q)
        self.assertEqual(status, 200)
        self.assertEqual(body["capacity"], 6)
        # 本用例所有提交都被拒绝，18:00 剩余桌数应与用例开始前一致
        self.assertEqual(body["slots"]["18:00"], baseline["18:00"], body)

        # 真实占用核对：占 1 桌后剩余必须减 1，再占满后第 7 次必须 409
        alt = (self.today + timedelta(days=7)).isoformat()
        q_alt = urllib.parse.urlencode({"date": alt})
        _, before, _ = http("GET", self.base + "/api/slots?" + q_alt)
        self.assertEqual(before["capacity"], 6, before)
        slot = "20:30"
        remaining = before["slots"][slot]
        self.assertGreater(remaining, 0, before)
        status, body, _ = self.post(phone="13700000002", date=alt, time=slot)
        self.assertEqual(status, 201, body)
        _, after, _ = http("GET", self.base + "/api/slots?" + q_alt)
        self.assertEqual(after["slots"][slot], remaining - 1, after)
        for i in range(remaining - 1):
            st, b, _ = self.post(phone=f"1370001{i:04d}", date=alt, time=slot)
            self.assertEqual(st, 201, b)
        _, full, _ = http("GET", self.base + "/api/slots?" + q_alt)
        self.assertEqual(full["slots"][slot], 0, full)
        st, b, _ = self.post(phone="13700019999", date=alt, time=slot)
        self.assertEqual(st, 409, b)
        self.assertIn("订满", b["error"])
        _, still, _ = http("GET", self.base + "/api/slots?" + q_alt)
        self.assertEqual(still["slots"][slot], 0, still)

    def test_05_duplicate_rejected(self):
        first = self.post(phone="13600000003", time="12:00")
        self.assertEqual(first[0], 201, first[1])
        code = first[1]["reservation"]["code"]
        status, body, _ = self.post(phone="13600000003", time="12:00")
        self.assertEqual(status, 409)
        self.assertIn("已有预订", body["error"])
        self.assertEqual(body["code"], code)
        # 同手机号换时段可以
        self.assertEqual(self.post(phone="13600000003", time="12:30")[0], 201)

    def test_06_capacity_limit(self):
        slot = "19:30"
        codes = []
        for i in range(6):
            status, body, _ = self.post(phone=f"1350000{i:04d}", time=slot)
            self.assertEqual(status, 201, body)
            codes.append(body["reservation"]["code"])
        status, body, _ = self.post(phone="13500009999", time=slot)
        self.assertEqual(status, 409)
        self.assertIn("订满", body["error"])
        # 其他时段仍可订
        self.assertEqual(self.post(phone="13500009999", time="20:00")[0], 201)
        # 可用性接口反映满位
        _, avail, _ = http("GET", f"{self.base}/api/slots?date={self.day}")
        self.assertEqual(avail["slots"][slot], 0)
        self.assertGreater(avail["slots"]["11:30"], 0)

    def test_07_restart_persistence(self):
        status, body, _ = self.post(phone="13400000004", time="13:30", notes="重启后仍应可查")
        self.assertEqual(status, 201, body)
        rec = body["reservation"]
        self.server.stop()
        self.server = Server(self.data_dir).start()
        self.base = self.server.base
        q = urllib.parse.urlencode({"code": rec["code"], "phone": rec["phone"]})
        status, body, _ = http("GET", self.base + "/api/reservations?" + q)
        self.assertEqual(status, 200)
        self.assertEqual(body["reservation"]["notes"], "重启后仍应可查")
        self.assertEqual(body["reservation"]["created_at"], rec["created_at"])
        # 重启后数据库文件仍在数据目录
        self.assertTrue((self.data_dir / "jinyu_reservations.sqlite3").exists())


if __name__ == "__main__":
    unittest.main(verbosity=2)
