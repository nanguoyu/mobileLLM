/* 金玉满堂 · 前端交互（无依赖） */
(function () {
  'use strict';

  const LUNCH = ['11:30', '12:00', '12:30', '13:00', '13:30'];
  const DINNER = ['17:30', '18:00', '18:30', '19:00', '19:30', '20:00', '20:30'];
  const SLOTS = LUNCH.concat(DINNER);
  const MAX_ADVANCE = 60;
  const PHONE_RE = /^1[3-9]\d{9}$/;

  const $ = (sel, root) => (root || document).querySelector(sel);
  const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));

  function isoDate(d) {
    const p = (n) => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
  }
  const today = new Date();
  const todayISO = isoDate(today);
  const maxISO = isoDate(new Date(today.getFullYear(), today.getMonth(), today.getDate() + MAX_ADVANCE));

  /* ---------- 导航 ---------- */
  const navToggle = $('#navToggle');
  const siteNav = $('#siteNav');
  navToggle.addEventListener('click', () => {
    const open = siteNav.classList.toggle('open');
    navToggle.setAttribute('aria-expanded', String(open));
  });
  siteNav.addEventListener('click', (e) => {
    if (e.target.tagName === 'A') {
      siteNav.classList.remove('open');
      navToggle.setAttribute('aria-expanded', 'false');
    }
  });

  /* ---------- 时段按钮 ---------- */
  function buildSlot(container, times, name) {
    container.innerHTML = '';
    times.forEach((t) => {
      const label = document.createElement('label');
      label.className = 'slot';
      label.innerHTML =
        `<input type="radio" name="${name}" value="${t}" aria-label="${t}">` +
        `<span>${t}</span><em>满</em>`;
      container.appendChild(label);
    });
  }
  buildSlot($('#lunchSlots'), LUNCH, 'time');
  buildSlot($('#dinnerSlots'), DINNER, 'time');

  const dateInput = $('#date');
  const partyInput = $('#party');
  const form = $('#bookingForm');
  const formError = $('#formError');
  const submitBtn = $('#submitBtn');
  const confirmCard = $('#confirmCard');
  const nameInput = $('#name');
  const phoneInput = $('#phone');
  const notesInput = $('#notes');

  dateInput.min = todayISO;
  dateInput.max = maxISO;
  dateInput.value = todayISO;

  function selectedSlot() {
    const el = form.querySelector('input[name="time"]:checked');
    return el ? el.value : '';
  }

  async function refreshAvailability() {
    const day = dateInput.value;
    if (!/^\d{4}-\d{2}-\d{2}$/.test(day)) return;
    try {
      const res = await fetch(`/api/slots?date=${encodeURIComponent(day)}`, { headers: { Accept: 'application/json' } });
      if (!res.ok) return;
      const data = await res.json();
      $$('.slot input').forEach((input) => {
        const left = data.slots[input.value];
        const full = typeof left === 'number' && left <= 0;
        input.disabled = full;
        if (full && input.checked) input.checked = false;
        const span = input.nextElementSibling;
        span.title = full ? '该时段已订满' : `剩余 ${left} 桌`;
      });
    } catch (err) {
      /* 离线时仍可提交，由服务端最终校验 */
    }
  }
  dateInput.addEventListener('change', refreshAvailability);
  refreshAvailability();

  /* ---------- 人数步进 ---------- */
  $$('.step-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      const step = Number(btn.dataset.step);
      let v = parseInt(partyInput.value || '2', 10);
      if (Number.isNaN(v)) v = 2;
      v = Math.min(12, Math.max(1, v + step));
      partyInput.value = String(v);
      clearError('party_size');
    });
  });

  /* ---------- 校验 ---------- */
  function setError(field, msg) {
    const p = $(`[data-err="${field}"]`);
    if (p) p.textContent = msg || '';
    const input = field === 'party_size' ? partyInput : form.elements[field];
    if (input && input.setAttribute) {
      if (msg) input.setAttribute('aria-invalid', 'true');
      else input.removeAttribute('aria-invalid');
    }
  }
  function clearError(field) { setError(field, ''); }
  function clearAll() { ['name', 'phone', 'date', 'time', 'party_size', 'notes'].forEach(clearError); }

  function validate(values) {
    const errors = {};
    const name = values.name.trim();
    if (name.length < 2 || name.length > 20) errors.name = '请填写 2-20 个字的姓名';
    if (!PHONE_RE.test(values.phone.replace(/[\s-]/g, ''))) errors.phone = '请输入 11 位中国大陆手机号';
    if (!values.date) errors.date = '请选择用餐日期';
    else if (values.date < todayISO) errors.date = '日期不能早于今天';
    else if (values.date > maxISO) errors.date = `最多可提前 ${MAX_ADVANCE} 天预订`;
    if (!SLOTS.includes(values.time)) errors.time = '请选择一个用餐时段';
    const party = Number(values.party_size);
    if (!Number.isInteger(party) || party < 1 || party > 12) errors.party_size = '人数需为 1-12 的整数';
    if (values.notes.length > 200) errors.notes = '备注最多 200 字';
    return errors;
  }

  function collect() {
    return {
      name: nameInput.value,
      phone: phoneInput.value,
      date: dateInput.value,
      time: selectedSlot(),
      party_size: partyInput.value,
      notes: notesInput.value,
    };
  }

  ['name', 'phone', 'date', 'notes'].forEach((id) => {
    const el = form.elements[id];
    el.addEventListener('input', () => clearError(id));
    el.addEventListener('change', () => clearError(id));
  });
  form.addEventListener('change', (e) => {
    if (e.target.name === 'time') clearError('time');
  });

  /* ---------- 提交 ---------- */
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    formError.hidden = true;
    clearAll();
    const values = collect();
    const errors = validate(values);
    if (Object.keys(errors).length) {
      Object.entries(errors).forEach(([k, v]) => setError(k, v));
      const first = form.querySelector('[aria-invalid="true"]');
      if (first) first.focus();
      return;
    }
    submitBtn.disabled = true;
    const original = submitBtn.textContent;
    submitBtn.textContent = '正在锁位…';
    try {
      const res = await fetch('/api/reservations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify(values),
      });
      let data = {};
      try { data = await res.json(); } catch (err) { data = {}; }
      if (!res.ok) {
        if (data.fields) {
          Object.entries(data.fields).forEach(([k, v]) => setError(k, v));
          const first = form.querySelector('[aria-invalid="true"]');
          if (first) first.focus();
        }
        formError.textContent = data.error || '订台失败，请稍后重试';
        formError.hidden = false;
        if (res.status === 409) refreshAvailability();
        return;
      }
      showConfirmation(data.reservation);
    } catch (err) {
      formError.textContent = '网络异常，请检查连接后重试，或致电 020-8888 9999。';
      formError.hidden = false;
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = original;
    }
  });

  function fmtDate(iso) {
    const [y, m, d] = iso.split('-');
    const week = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'][new Date(`${iso}T00:00:00`).getDay()];
    return `${y}年${Number(m)}月${Number(d)}日 ${week}`;
  }

  function fillList(dl, rec) {
    const rows = [
      ['确认码', rec.code],
      ['姓名', rec.name],
      ['手机', rec.phone],
      ['日期', fmtDate(rec.date)],
      ['时段', rec.time],
      ['人数', `${rec.party_size} 位`],
      ['备注', rec.notes || '无'],
    ];
    dl.innerHTML = '';
    rows.forEach(([k, v]) => {
      const row = document.createElement('div');
      const dt = document.createElement('dt');
      const dd = document.createElement('dd');
      dt.textContent = k;
      dd.textContent = v;
      row.append(dt, dd);
      dl.appendChild(row);
    });
  }

  function showConfirmation(rec) {
    $('#confirmCode').textContent = rec.code;
    fillList($('#confirmList'), rec);
    form.hidden = true;
    confirmCard.hidden = false;
    confirmCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
    $('#lookupCode').value = rec.code;
    $('#lookupPhone').value = rec.phone;
    refreshAvailability();
  }

  $('#againBtn').addEventListener('click', () => {
    form.reset();
    dateInput.value = todayISO;
    partyInput.value = '2';
    clearAll();
    formError.hidden = true;
    confirmCard.hidden = true;
    form.hidden = false;
    nameInput.focus();
    refreshAvailability();
  });

  /* ---------- 查询 ---------- */
  const lookupForm = $('#lookupForm');
  const lookupError = $('#lookupError');
  const lookupResult = $('#lookupResult');

  lookupForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    lookupError.hidden = true;
    lookupResult.hidden = true;
    const code = $('#lookupCode').value.trim().toUpperCase();
    const phone = $('#lookupPhone').value.trim();
    if (!code) { lookupError.textContent = '请输入确认码'; lookupError.hidden = false; return; }
    if (!PHONE_RE.test(phone)) { lookupError.textContent = '请输入订台时的 11 位手机号'; lookupError.hidden = false; return; }
    try {
      const res = await fetch(`/api/reservations?code=${encodeURIComponent(code)}&phone=${encodeURIComponent(phone)}`);
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        lookupError.textContent = data.error || '查询失败，请稍后重试';
        lookupError.hidden = false;
        return;
      }
      fillList($('#lookupList'), data.reservation);
      lookupResult.hidden = false;
      lookupResult.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    } catch (err) {
      lookupError.textContent = '网络异常，请稍后重试。';
      lookupError.hidden = false;
    }
  });
})();
