#!/usr/bin/env python3
"""金玉满堂 · 中餐馆官网 + 在线订台服务

纯标准库实现：http.server + sqlite3，无第三方依赖。

启动：
    MOBILELLM_DATA_DIR=/workspace/data python3 app.py --host 0.0.0.0 --port 8000

数据文件：$MOBILELLM_DATA_DIR/jinyu_reservations.sqlite3（未设变量时为 ./data）
接口：
    GET  /api/health
    GET  /api/slots?date=YYYY-MM-DD
    POST /api/reservations
    GET  /api/reservations?code=JYXXXXXX&phone=13xxxxxxxxx
"""
from __future__ import annotations

import argparse
import json
import os
import re
import secrets
import signal
import sqlite3
import sys
import threading
import time
import traceback
from datetime import date, datetime, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"

# ---------------------------------------------------------------------------
# 业务规则
# ---------------------------------------------------------------------------
LUNCH_SLOTS = ("11:30", "12:00", "12:30", "13:00", "13:30")
DINNER_SLOTS = ("17:30", "18:00", "18:30", "19:00", "19:30", "20:00", "20:30")
SLOTS = LUNCH_SLOTS + DINNER_SLOTS
SLOT_CAPACITY = 6          # 每时段最多 6 桌
MAX_ADVANCE_DAYS = 60      # 最多提前 60 天
MAX_PARTY = 12
PHONE_RE = re.compile(r"^1[3-9]\d{9}$")
CODE_RE = re.compile(r"^JY[A-Z0-9]{6}$")
CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
DB_FILENAME = "jinyu_reservations.sqlite3"
MAX_BODY = 64 * 1024


def data_dir() -> Path:
    raw = os.environ.get("MOBILELLM_DATA_DIR")
    path = Path(raw).expanduser() if raw else BASE_DIR / "data"
    path.mkdir(parents=True, exist_ok=True)
    return path.resolve()


def today() -> date:
    return date.today()


# ---------------------------------------------------------------------------
# 存储层
# ---------------------------------------------------------------------------
class DuplicateError(Exception):
    def __init__(self, code: str):
        super().__init__("duplicate")
        self.code = code


class CapacityError(Exception):
    pass


class Store:
    """SQLite 持久化。每次操作新建连接；写入用 BEGIN IMMEDIATE + 进程锁串行化。"""

    def __init__(self, path: Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._init_schema()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.path), timeout=15, isolation_level=None)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA busy_timeout = 15000")
        return conn

    def _init_schema(self) -> None:
        conn = self._connect()
        try:
            conn.execute("PRAGMA journal_mode = WAL")
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS reservations (
                    code       TEXT PRIMARY KEY,
                    name       TEXT NOT NULL,
                    phone      TEXT NOT NULL,
                    date       TEXT NOT NULL,
                    time       TEXT NOT NULL,
                    party_size INTEGER NOT NULL CHECK (party_size BETWEEN 1 AND 12),
                    notes      TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL
                );
                CREATE UNIQUE INDEX IF NOT EXISTS ux_reservations_phone_slot
                    ON reservations(phone, date, time);
                CREATE INDEX IF NOT EXISTS ix_reservations_date_time
                    ON reservations(date, time);
                """
            )
        finally:
            conn.close()

    @staticmethod
    def _row(row: sqlite3.Row) -> dict:
        return {
            "code": row["code"],
            "name": row["name"],
            "phone": row["phone"],
            "date": row["date"],
            "time": row["time"],
            "party_size": row["party_size"],
            "notes": row["notes"],
            "created_at": row["created_at"],
        }

    def create(self, name: str, phone: str, day: str, time_slot: str,
               party_size: int, notes: str) -> dict:
        created = datetime.now().replace(microsecond=0).isoformat()
        with self._lock:
            conn = self._connect()
            try:
                conn.execute("BEGIN IMMEDIATE")
                dup = conn.execute(
                    "SELECT code FROM reservations WHERE phone=? AND date=? AND time=?",
                    (phone, day, time_slot),
                ).fetchone()
                if dup:
                    conn.execute("ROLLBACK")
                    raise DuplicateError(dup["code"])
                used = conn.execute(
                    "SELECT COUNT(*) AS n FROM reservations WHERE date=? AND time=?",
                    (day, time_slot),
                ).fetchone()["n"]
                if used >= SLOT_CAPACITY:
                    conn.execute("ROLLBACK")
                    raise CapacityError(time_slot)
                for _ in range(8):
                    code = "JY" + "".join(secrets.choice(CODE_ALPHABET) for _ in range(6))
                    try:
                        conn.execute(
                            "INSERT INTO reservations"
                            " (code,name,phone,date,time,party_size,notes,created_at)"
                            " VALUES (?,?,?,?,?,?,?,?)",
                            (code, name, phone, day, time_slot, party_size, notes, created),
                        )
                        conn.execute("COMMIT")
                        row = conn.execute(
                            "SELECT * FROM reservations WHERE code=?", (code,)
                        ).fetchone()
                        return self._row(row)
                    except sqlite3.IntegrityError as exc:
                        conn.execute("ROLLBACK")
                        msg = str(exc).upper()
                        if "UX_RESERVATIONS_PHONE_SLOT" in msg or "UNIQUE" in msg:
                            again = conn.execute(
                                "SELECT code FROM reservations WHERE phone=? AND date=? AND time=?",
                                (phone, day, time_slot),
                            ).fetchone()
                            if again:
                                raise DuplicateError(again["code"]) from exc
                        continue  # 确认码碰撞，换一个重试
                raise RuntimeError("无法生成唯一确认码")
            finally:
                conn.close()

    def find(self, code: str, phone: str) -> dict | None:
        conn = self._connect()
        try:
            row = conn.execute(
                "SELECT * FROM reservations WHERE code=? AND phone=?",
                (code.upper(), phone),
            ).fetchone()
            return self._row(row) if row else None
        finally:
            conn.close()

    def availability(self, day: str) -> dict[str, int]:
        conn = self._connect()
        try:
            rows = conn.execute(
                "SELECT time, COUNT(*) AS n FROM reservations WHERE date=? GROUP BY time",
                (day,),
            ).fetchall()
            used = {r["time"]: r["n"] for r in rows}
        finally:
            conn.close()
        return {slot: max(0, SLOT_CAPACITY - used.get(slot, 0)) for slot in SLOTS}


# ---------------------------------------------------------------------------
# 校验
# ---------------------------------------------------------------------------
def validate(payload: dict) -> tuple[dict, dict[str, str]]:
    """返回 (清洗后的值, 字段错误)。服务端不信任任何客户端校验。"""
    errors: dict[str, str] = {}
    clean: dict = {}

    raw_name = payload.get("name")
    name = raw_name.strip() if isinstance(raw_name, str) else ""
    name = re.sub(r"\s+", " ", name)
    if not (2 <= len(name) <= 20):
        errors["name"] = "请填写 2-20 个字的姓名"
    else:
        clean["name"] = name

    raw_phone = payload.get("phone")
    phone = re.sub(r"[\s-]", "", raw_phone) if isinstance(raw_phone, str) else ""
    if not PHONE_RE.match(phone):
        errors["phone"] = "请输入 11 位中国大陆手机号"
    else:
        clean["phone"] = phone

    raw_date = payload.get("date")
    day = raw_date.strip() if isinstance(raw_date, str) else ""
    if not day:
        errors["date"] = "请选择用餐日期"
    else:
        try:
            parsed = datetime.strptime(day, "%Y-%m-%d").date()
        except ValueError:
            errors["date"] = "日期格式应为 YYYY-MM-DD"
        else:
            if parsed < today():
                errors["date"] = "用餐日期不能早于今天"
            elif parsed > today() + timedelta(days=MAX_ADVANCE_DAYS):
                errors["date"] = f"最多可提前 {MAX_ADVANCE_DAYS} 天预订"
            else:
                clean["date"] = parsed.isoformat()

    raw_slot = payload.get("time")
    slot = raw_slot.strip() if isinstance(raw_slot, str) else ""
    if slot not in SLOTS:
        errors["time"] = "请选择合法的用餐时段"
    else:
        clean["time"] = slot

    raw_party = payload.get("party_size")
    party = None
    if isinstance(raw_party, bool):
        party = None
    elif isinstance(raw_party, int):
        party = raw_party
    elif isinstance(raw_party, str) and re.fullmatch(r"\d{1,2}", raw_party.strip()):
        party = int(raw_party.strip())
    if party is None or not (1 <= party <= MAX_PARTY):
        errors["party_size"] = f"人数需为 1-{MAX_PARTY} 的整数"
    else:
        clean["party_size"] = party

    raw_notes = payload.get("notes")
    if raw_notes is None:
        notes = ""
    elif isinstance(raw_notes, str):
        notes = raw_notes.strip()
    else:
        notes = None
        errors["notes"] = "备注格式不正确"
    if notes is not None:
        if len(notes) > 200:
            errors["notes"] = "备注最多 200 字"
        else:
            clean["notes"] = notes

    return clean, errors


# ---------------------------------------------------------------------------
# HTTP
# ---------------------------------------------------------------------------
CONTENT_TYPES = {
    ".html": "text/html; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".js": "application/javascript; charset=utf-8",
    ".svg": "image/svg+xml",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".webp": "image/webp",
    ".ico": "image/x-icon",
    ".woff2": "font/woff2",
    ".json": "application/json; charset=utf-8",
}

NOT_FOUND_HTML = """<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>页面未找到 · 金玉满堂</title>
<style>body{font-family:system-ui,sans-serif;background:#f7f1e6;color:#1c1512;display:grid;place-items:center;min-height:100vh;margin:0;text-align:center}a{color:#8c1c22}</style>
</head><body><div><p style="letter-spacing:.3em;color:#b8893f;font-size:.8rem">404</p>
<h1>这道菜还没上桌</h1><p>页面不存在，<a href="/">回首页</a> 或 <a href="/#booking">直接订台</a>。</p></div></body></html>"""


class Handler(BaseHTTPRequestHandler):
    server_version = "JinyuMantang/1.0"
    sys_version = ""
    protocol_version = "HTTP/1.1"

    store: Store
    started_at: float = 0.0

    # ---------- 工具 ----------
    def _send(self, status: int, body: bytes, ctype: str, extra: dict | None = None) -> None:
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "same-origin")
        self.send_header(
            "Content-Security-Policy",
            "default-src 'self'; img-src 'self' data:; style-src 'self'; "
            "script-src 'self'; base-uri 'none'; form-action 'self'",
        )
        if extra:
            for k, v in extra.items():
                self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _json(self, status: int, payload: dict) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self._send(status, body, "application/json; charset=utf-8", {"Cache-Control": "no-store"})

    def _error(self, status: int, message: str, **extra) -> None:
        payload = {"error": message, "status": status}
        payload.update(extra)
        self._json(status, payload)

    def log_message(self, fmt: str, *args) -> None:
        sys.stderr.write("[%s] %s\n" % (self.log_date_time_string(), fmt % args))

    # ---------- 路由 ----------
    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        path = parsed.path
        query = parse_qs(parsed.query)
        try:
            if path == "/api/health":
                return self.api_health()
            if path == "/api/slots":
                return self.api_slots(query)
            if path == "/api/reservations":
                return self.api_lookup(query)
            if path.startswith("/api/"):
                return self._error(404, "接口不存在")
            return self.serve_static(path)
        except (BrokenPipeError, ConnectionResetError):
            return
        except Exception:
            traceback.print_exc()
            try:
                return self._error(500, "服务器内部错误")
            except Exception:
                return

    def do_HEAD(self) -> None:
        self.do_GET()

    def do_POST(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path != "/api/reservations":
            return self._error(404, "接口不存在")
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            return self._error(400, "请求体长度无效")
        if length > MAX_BODY:
            return self._error(413, "请求体过大")
        if length == 0:
            return self._error(400, "缺少请求体")
        raw = self.rfile.read(length)
        try:
            payload = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            return self._error(400, "请求体必须是合法 JSON")
        if not isinstance(payload, dict):
            return self._error(400, "请求体必须是 JSON 对象")

        clean, errors = validate(payload)
        if errors:
            return self._json(422, {"error": "请检查填写的信息", "fields": errors})
        try:
            record = self.store.create(
                name=clean["name"],
                phone=clean["phone"],
                day=clean["date"],
                time_slot=clean["time"],
                party_size=clean["party_size"],
                notes=clean.get("notes", ""),
            )
        except DuplicateError as exc:
            return self._json(409, {
                "error": "该手机号在此日期时段已有预订，请勿重复提交",
                "code": exc.code,
            })
        except CapacityError:
            return self._json(409, {
                "error": "该时段已订满，请选择其他时段或日期",
                "fields": {"time": "该时段已订满"},
            })
        except Exception:
            # 任何意外异常都必须返回 JSON 500，绝不能让连接静默断开
            traceback.print_exc()
            return self._json(500, {
                "error": "服务器内部错误，请稍后重试或致电 020-8123-4567",
                "status": 500,
            })
        return self._json(201, {"ok": True, "reservation": record})

    # ---------- 接口 ----------
    def api_health(self) -> None:
        try:
            conn = self.store._connect()
            try:
                conn.execute("SELECT 1 FROM reservations LIMIT 1").fetchall()
            finally:
                conn.close()
        except Exception as exc:  # pragma: no cover
            return self._json(503, {"status": "error", "detail": str(exc)})
        self._json(200, {
            "status": "ok",
            "service": "jinyu-mantang",
            "time": datetime.now().replace(microsecond=0).isoformat(),
            "uptime_seconds": round(time.time() - self.started_at, 1),
            "db": str(self.store.path),
            "slot_capacity": SLOT_CAPACITY,
        })

    def api_slots(self, query: dict) -> None:
        raw = (query.get("date") or [""])[0].strip()
        if not raw:
            day = today().isoformat()
        else:
            try:
                day = datetime.strptime(raw, "%Y-%m-%d").date().isoformat()
            except ValueError:
                return self._error(400, "日期格式应为 YYYY-MM-DD")
        self._json(200, {
            "date": day,
            "capacity": SLOT_CAPACITY,
            "slots": self.store.availability(day),
            "lunch": list(LUNCH_SLOTS),
            "dinner": list(DINNER_SLOTS),
        })

    def api_lookup(self, query: dict) -> None:
        code = (query.get("code") or [""])[0].strip().upper()
        phone = re.sub(r"[\s-]", "", (query.get("phone") or [""])[0])
        if not code or not phone:
            return self._error(400, "请提供确认码和手机号")
        if not CODE_RE.match(code):
            return self._error(400, "确认码格式不正确")
        if not PHONE_RE.match(phone):
            return self._error(400, "手机号格式不正确")
        record = self.store.find(code, phone)
        if not record:
            return self._error(404, "未找到匹配的预订，请核对确认码与手机号")
        self._json(200, {"ok": True, "reservation": record})

    # ---------- 静态文件 ----------
    def serve_static(self, path: str) -> None:
        if path in ("", "/"):
            path = "/index.html"
        rel = path.lstrip("/")
        target = (STATIC_DIR / rel).resolve()
        try:
            target.relative_to(STATIC_DIR.resolve())
        except ValueError:
            return self._not_found()
        if not target.is_file():
            return self._not_found()
        suffix = target.suffix.lower()
        ctype = CONTENT_TYPES.get(suffix, "application/octet-stream")
        cache = "no-cache" if suffix == ".html" else "public, max-age=300"
        self._send(200, target.read_bytes(), ctype, {"Cache-Control": cache})

    def _not_found(self) -> None:
        if self.path.startswith("/api/"):
            return self._error(404, "接口不存在")
        self._send(404, NOT_FOUND_HTML.encode("utf-8"), "text/html; charset=utf-8",
                   {"Cache-Control": "no-store"})


class AppServer(ThreadingHTTPServer):
    allow_reuse_address = True
    daemon_threads = True


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="金玉满堂订台服务")
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument("--data-dir", default=None, help="覆盖数据目录（默认读 MOBILELLM_DATA_DIR）")
    args = parser.parse_args(argv)

    if args.data_dir:
        os.environ["MOBILELLM_DATA_DIR"] = args.data_dir
    store = Store(data_dir() / DB_FILENAME)

    Handler.store = store
    Handler.started_at = time.time()
    httpd = AppServer((args.host, args.port), Handler)

    def shutdown(signum, frame):
        threading.Thread(target=httpd.shutdown, daemon=True).start()

    signal.signal(signal.SIGTERM, shutdown)
    signal.signal(signal.SIGINT, shutdown)

    print(f"金玉满堂订台服务已启动：http://{args.host}:{args.port}  db={store.path}", flush=True)
    try:
        httpd.serve_forever(poll_interval=0.3)
    finally:
        httpd.server_close()
        print("服务已停止", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
