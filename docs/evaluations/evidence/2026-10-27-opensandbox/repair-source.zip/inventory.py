def reserve(stock, requests):
    """Return a new stock mapping with the requested quantities deducted.

    Repeated requests for the same SKU are aggregated. The entire batch is
    validated before any stock is deducted, and neither ``stock`` nor
    ``requests`` is modified.
    """
    totals = {}
    for request in requests:
        try:
            sku, qty = request
        except (TypeError, ValueError):
            raise ValueError('invalid request')
        if isinstance(qty, bool) or not isinstance(qty, int) or qty <= 0:
            raise ValueError('invalid quantity')
        totals[sku] = totals.get(sku, 0) + qty

    for sku, qty in totals.items():
        if stock.get(sku, 0) < qty:
            raise ValueError('insufficient stock')

    remaining = dict(stock)
    for sku, qty in totals.items():
        remaining[sku] = remaining.get(sku, 0) - qty
    return remaining
