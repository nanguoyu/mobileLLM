import unittest
from inventory import reserve
class InventoryTests(unittest.TestCase):
    def test_success_preserves_input(self):
        stock = {'rice': 8, 'tea': 3}
        self.assertEqual(reserve(stock, [('rice', 2), ('rice', 3)]), {'rice': 3, 'tea': 3})
        self.assertEqual(stock, {'rice': 8, 'tea': 3})
    def test_failed_batch_is_atomic(self):
        stock = {'rice': 8, 'tea': 3}
        with self.assertRaises(ValueError): reserve(stock, [('rice', 3), ('tea', 4)])
        self.assertEqual(stock, {'rice': 8, 'tea': 3})
    def test_invalid_quantities(self):
        for qty in [0, -1, 1.5, True]:
            with self.assertRaises(ValueError): reserve({'rice': 8}, [('rice', qty)])
if __name__ == '__main__': unittest.main()
