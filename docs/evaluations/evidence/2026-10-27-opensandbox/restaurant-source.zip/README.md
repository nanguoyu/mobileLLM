# 蜀香粤味 · 中餐馆官网与在线订台系统

一个可直接运行的中餐馆网站示例：Express + SQLite（Node 内置 `node:sqlite`）后端，原生 HTML/CSS/JS 前端。

## 运行

```bash
npm install          # 仅需 express
PORT=3000 MOBILELLM_DATA_DIR=/workspace/data npm start
# 打开 http://localhost:3000
```

- 首页：`/`
- 在线订台：`/reserve.html`
- 管理后台：`/admin.html`
- 数据库文件：`$MOBILELLM_DATA_DIR/restaurant.db`（默认 `./data/restaurant.db`）

可选环境变量：

| 变量 | 说明 | 默认 |
| --- | --- | --- |
| `PORT` | 监听端口 | `3000` |
| `HOST` | 监听地址 | `0.0.0.0` |
| `MOBILELLM_DATA_DIR` | 运行数据目录 | `./data` |
| `SLOT_CAPACITY` | 每个时段可接的桌数 | `4` |
| `ADMIN_TOKEN` | 设置后，管理接口需 `x-admin-token` 请求头 | 空（不校验） |

## REST API

### `GET /api/reservations/availability?date=YYYY-MM-DD`

返回该日期全部时段、每时段已订桌数/剩余桌数，以及已有时段的 `bookedSlots` 数组。过去日期或超出 60 天返回 400。

```json
{
  "date": "2026-10-28",
  "capacityPerSlot": 4,
  "slots": [{ "time": "19:00", "period": "晚餐", "capacity": 4, "booked": 1, "remaining": 3, "full": false }],
  "bookedSlots": ["19:00"],
  "availableSlots": ["11:30", "..."]
}
```

### `POST /api/reservations`

```json
{ "name": "张伟", "phone": "13800138000", "date": "2026-10-28", "time": "19:00", "partySize": 4, "note": "靠窗" }
```

校验：姓名 2-30 字；手机号 11 位（或座机）；日期为今天起 60 天内；时段必须在营业时段内；人数 1-20 的整数；备注 ≤200 字。

- `201` 成功，返回 `{ reservation: { id, code, ... } }`
- `400` 校验失败，`{ error, fields: { name: '...' } }`
- `409` 时段订满或同手机号同时段重复预订

### `GET /api/reservations`（管理）

可选 `?date=YYYY-MM-DD&status=confirmed&limit=200`，返回 `{ total, guests, reservations }`。若设置了 `ADMIN_TOKEN`，需带 `x-admin-token` 头或 `?token=`。

### `PATCH /api/reservations/:id/cancel`（管理）

把预订标记为 `cancelled`，释放该时段名额。

### `GET /api/health`

健康检查。

## 测试

```bash
node test.js
```

`test.js` 会在独立端口（默认 4599）和独立数据目录启动服务器，覆盖：创建预订、可订时段反映新预订、管理列表、9 类无效输入、重复预订、时段订满，以及**重启服务器后数据仍在**的持久化验证。

## 说明与限制

- 餐厅名称、地址、电话、菜品价格为演示内容，非真实商户。
- 管理后台默认无鉴权（便于本地演示）；生产环境请设置 `ADMIN_TOKEN` 并置于 HTTPS 之后。
- 未接入短信验证、支付、邮件通知；订台成功仅返回预订号。
- 时段容量按“桌数”计算（每时段 4 桌），未按桌型/人数合并优化。
