'use strict';

const assert = require('node:assert/strict');
const { spawn } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');

const PORT = Number(process.env.TEST_PORT || 4599);
const BASE = `http://127.0.0.1:${PORT}`;
const ROOT = __dirname;
const DATA_ROOT = process.env.MOBILELLM_DATA_DIR || path.join(ROOT, 'data');
const DATA_DIR = path.join(DATA_ROOT, `test-${Date.now()}`);
fs.mkdirSync(DATA_DIR, { recursive: true });

let child = null;
let passed = 0;
const failures = [];

function shanghaiToday() {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Shanghai',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  }).format(new Date());
}

function addDays(iso, days) {
  const [y, m, d] = iso.split('-').map(Number);
  return new Date(Date.UTC(y, m - 1, d + days)).toISOString().slice(0, 10);
}

const TODAY = shanghaiToday();
const TOMORROW = addDays(TODAY, 1);
const YESTERDAY = addDays(TODAY, -1);

function startServer() {
  return new Promise((resolve, reject) => {
    child = spawn(process.execPath, [path.join(ROOT, 'server.js')], {
      env: {
        ...process.env,
        PORT: String(PORT),
        HOST: '127.0.0.1',
        MOBILELLM_DATA_DIR: DATA_DIR,
        ADMIN_TOKEN: ''
      },
      stdio: ['ignore', 'pipe', 'pipe']
    });
    let out = '';
    let settled = false;
    child.stdout.on('data', (d) => {
      out += d.toString();
      if (!settled && out.includes('listening')) {
        settled = true;
        resolve();
      }
    });
    child.stderr.on('data', (d) => process.stderr.write(d));
    child.on('exit', (code) => {
      if (!settled) {
        settled = true;
        reject(new Error(`server exited with code ${code}`));
      }
    });
    setTimeout(() => {
      if (!settled) {
        settled = true;
        reject(new Error(`server start timeout. output: ${out}`));
      }
    }, 15000).unref();
  });
}

function stopServer() {
  return new Promise((resolve) => {
    if (!child) return resolve();
    const proc = child;
    child = null;
    proc.once('exit', () => resolve());
    proc.kill('SIGTERM');
    setTimeout(() => {
      try {
        proc.kill('SIGKILL');
      } catch (err) {
        /* already gone */
      }
    }, 4000).unref();
  });
}

async function request(pathname, options) {
  const res = await fetch(BASE + pathname, options);
  let body = null;
  try {
    body = await res.json();
  } catch (err) {
    body = null;
  }
  return { status: res.status, body };
}

async function check(label, fn) {
  try {
    await fn();
    passed += 1;
    console.log(`✓ ${label}`);
  } catch (err) {
    failures.push({ label, error: err.message });
    console.log(`✗ ${label}\n   ${err.message}`);
  }
}

const jsonPost = (payload) => ({
  method: 'POST',
  headers: { 'content-type': 'application/json' },
  body: JSON.stringify(payload)
});

async function main() {
  console.log(`测试数据目录: ${DATA_DIR}`);
  console.log(`测试日期: ${TOMORROW} (今天 ${TODAY}, 上海时区)\n`);
  await startServer();

  let createdId = null;
  let createdCode = null;

  await check('健康检查 /api/health 返回 ok', async () => {
    const { status, body } = await request('/api/health');
    assert.equal(status, 200);
    assert.equal(body.ok, true);
  });

  await check('可订时段查询返回 14 个时段且初始无已订时段', async () => {
    const { status, body } = await request(`/api/reservations/availability?date=${TOMORROW}`);
    assert.equal(status, 200);
    assert.equal(body.date, TOMORROW);
    assert.equal(body.slots.length, 14);
    assert.deepEqual(body.bookedSlots, []);
    assert.equal(body.slots.find((s) => s.time === '19:00').remaining, 4);
  });

  await check('创建预订成功并返回 201 与预订号', async () => {
    const { status, body } = await request(
      '/api/reservations',
      jsonPost({ name: '张伟', phone: '13800138000', date: TOMORROW, time: '19:00', partySize: 4, note: '靠窗座位' })
    );
    assert.equal(status, 201);
    assert.ok(body.reservation, 'missing reservation');
    assert.equal(body.reservation.name, '张伟');
    assert.equal(body.reservation.phone, '13800138000');
    assert.equal(body.reservation.date, TOMORROW);
    assert.equal(body.reservation.time, '19:00');
    assert.equal(body.reservation.partySize, 4);
    assert.equal(body.reservation.status, 'confirmed');
    assert.match(body.reservation.code, /^SX\d{8}[A-Z0-9]{5}$/);
    createdId = body.reservation.id;
    createdCode = body.reservation.code;
  });

  await check('可订时段反映新预订（bookedSlots 含 19:00，剩余 3 桌）', async () => {
    const { status, body } = await request(`/api/reservations/availability?date=${TOMORROW}`);
    assert.equal(status, 200);
    assert.ok(body.bookedSlots.includes('19:00'));
    const slot = body.slots.find((s) => s.time === '19:00');
    assert.equal(slot.booked, 1);
    assert.equal(slot.remaining, 3);
    assert.equal(slot.full, false);
  });

  await check('管理端列表 GET /api/reservations 包含该预订', async () => {
    const { status, body } = await request('/api/reservations');
    assert.equal(status, 200);
    const found = body.reservations.find((r) => r.id === createdId);
    assert.ok(found, 'reservation not found in admin list');
    assert.equal(found.code, createdCode);
    assert.equal(found.name, '张伟');
  });

  const invalidCases = [
    ['缺少姓名', { phone: '13800138000', date: TOMORROW, time: '19:00', partySize: 2 }, 'name'],
    ['姓名过短', { name: 'A', phone: '13800138000', date: TOMORROW, time: '19:00', partySize: 2 }, 'name'],
    ['手机号无效', { name: '李雷', phone: '123', date: TOMORROW, time: '19:00', partySize: 2 }, 'phone'],
    ['日期格式错误', { name: '李雷', phone: '13800138000', date: '2026/13/01', time: '19:00', partySize: 2 }, 'date'],
    ['过去日期被拒绝', { name: '李雷', phone: '13800138000', date: YESTERDAY, time: '19:00', partySize: 2 }, 'date'],
    ['非营业时段被拒绝', { name: '李雷', phone: '13800138000', date: TOMORROW, time: '10:00', partySize: 2 }, 'time'],
    ['人数为 0 被拒绝', { name: '李雷', phone: '13800138000', date: TOMORROW, time: '19:00', partySize: 0 }, 'partySize'],
    ['人数 21 被拒绝', { name: '李雷', phone: '13800138000', date: TOMORROW, time: '19:00', partySize: 21 }, 'partySize'],
    ['人数非整数被拒绝', { name: '李雷', phone: '13800138000', date: TOMORROW, time: '19:00', partySize: 2.5 }, 'partySize']
  ];

  for (const [label, payload, field] of invalidCases) {
    await check(`无效输入被拒绝：${label}`, async () => {
      const { status, body } = await request('/api/reservations', jsonPost(payload));
      assert.equal(status, 400);
      assert.ok(body.fields && body.fields[field], `expected fields.${field}, got ${JSON.stringify(body)}`);
    });
  }

  await check('同一手机号同一时段重复预订返回 409', async () => {
    const { status, body } = await request(
      '/api/reservations',
      jsonPost({ name: '张伟', phone: '13800138000', date: TOMORROW, time: '19:00', partySize: 2 })
    );
    assert.equal(status, 409);
    assert.match(body.error, /已预订/);
  });

  await check('时段订满后返回 409（容量 4 桌）', async () => {
    for (let i = 1; i <= 3; i += 1) {
      const res = await request(
        '/api/reservations',
        jsonPost({ name: `测试客人${i}`, phone: `1380013800${i}`, date: TOMORROW, time: '19:00', partySize: 2 })
      );
      assert.equal(res.status, 201, `fill #${i} failed: ${JSON.stringify(res.body)}`);
    }
    const full = await request(`/api/reservations/availability?date=${TOMORROW}`);
    const slot = full.body.slots.find((s) => s.time === '19:00');
    assert.equal(slot.remaining, 0);
    assert.equal(slot.full, true);
    const overflow = await request(
      '/api/reservations',
      jsonPost({ name: '王五', phone: '13800138009', date: TOMORROW, time: '19:00', partySize: 2 })
    );
    assert.equal(overflow.status, 409);
    assert.match(overflow.body.error, /订满/);
  });

  await check('重启服务器后预订仍存在（SQLite 持久化）', async () => {
    await stopServer();
    await startServer();
    const list = await request('/api/reservations');
    assert.equal(list.status, 200);
    const found = list.body.reservations.find((r) => r.id === createdId);
    assert.ok(found, 'reservation lost after restart');
    assert.equal(found.code, createdCode);
    const avail = await request(`/api/reservations/availability?date=${TOMORROW}`);
    assert.ok(avail.body.bookedSlots.includes('19:00'));
    assert.equal(avail.body.slots.find((s) => s.time === '19:00').booked, 4);
  });

  await stopServer();

  console.log(`\n通过 ${passed} 项，失败 ${failures.length} 项`);
  if (failures.length) {
    for (const f of failures) console.log(` - ${f.label}: ${f.error}`);
    process.exitCode = 1;
  } else {
    console.log('全部测试通过 ✅');
  }
}

main().catch(async (err) => {
  console.error('测试运行失败:', err);
  await stopServer();
  process.exitCode = 1;
});
