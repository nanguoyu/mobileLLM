'use strict';

const fs = require('node:fs');
const path = require('node:path');
const express = require('express');
const { DatabaseSync } = require('node:sqlite');

const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '0.0.0.0';
const DATA_DIR = process.env.MOBILELLM_DATA_DIR || path.join(__dirname, 'data');
fs.mkdirSync(DATA_DIR, { recursive: true });
const DB_FILE = process.env.DB_FILE || path.join(DATA_DIR, 'restaurant.db');

const SLOT_TIMES = [
  { time: '11:30', period: '午餐' },
  { time: '12:00', period: '午餐' },
  { time: '12:30', period: '午餐' },
  { time: '13:00', period: '午餐' },
  { time: '13:30', period: '午餐' },
  { time: '14:00', period: '午餐' },
  { time: '17:30', period: '晚餐' },
  { time: '18:00', period: '晚餐' },
  { time: '18:30', period: '晚餐' },
  { time: '19:00', period: '晚餐' },
  { time: '19:30', period: '晚餐' },
  { time: '20:00', period: '晚餐' },
  { time: '20:30', period: '晚餐' },
  { time: '21:00', period: '晚餐' }
];
const SLOT_INDEX = new Map(SLOT_TIMES.map((s) => [s.time, s]));
const SLOT_CAPACITY = Number(process.env.SLOT_CAPACITY || 4);
const MAX_DAYS_AHEAD = 60;
const ADMIN_TOKEN = process.env.ADMIN_TOKEN || '';

const db = new DatabaseSync(DB_FILE);
db.exec('PRAGMA journal_mode = WAL');
db.exec(`
  CREATE TABLE IF NOT EXISTS reservations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    phone TEXT NOT NULL,
    date TEXT NOT NULL,
    time TEXT NOT NULL,
    party_size INTEGER NOT NULL CHECK (party_size BETWEEN 1 AND 20),
    note TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'confirmed',
    created_at TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_reservations_date ON reservations (date, time);
  CREATE INDEX IF NOT EXISTS idx_reservations_phone ON reservations (phone, date, time);
`);

const insertStmt = db.prepare(`
  INSERT INTO reservations (code, name, phone, date, time, party_size, note, status, created_at)
  VALUES (?, ?, ?, ?, ?, ?, ?, 'confirmed', ?)
`);
const byIdStmt = db.prepare('SELECT * FROM reservations WHERE id = ?');
const countSlotStmt = db.prepare(
  "SELECT COUNT(*) AS n FROM reservations WHERE date = ? AND time = ? AND status = 'confirmed'"
);
const duplicateStmt = db.prepare(
  "SELECT id, code FROM reservations WHERE phone = ? AND date = ? AND time = ? AND status = 'confirmed'"
);

function shanghaiToday() {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Shanghai',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  }).format(new Date());
}

function addDays(isoDate, days) {
  const [y, m, d] = isoDate.split('-').map(Number);
  return new Date(Date.UTC(y, m - 1, d + days)).toISOString().slice(0, 10);
}

function isValidDateString(value) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const [y, m, d] = value.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  return dt.getUTCFullYear() === y && dt.getUTCMonth() === m - 1 && dt.getUTCDate() === d;
}

function validateDate(value) {
  if (!isValidDateString(value)) return { error: '请选择有效的日期（格式 YYYY-MM-DD）' };
  const today = shanghaiToday();
  if (value < today) return { error: '不能预订过去的日期，请选择今天或之后的日期' };
  if (value > addDays(today, MAX_DAYS_AHEAD)) {
    return { error: `仅支持预订 ${MAX_DAYS_AHEAD} 天以内的日期` };
  }
  return { value };
}

function normalizePhone(value) {
  return String(value == null ? '' : value).replace(/[\s-]/g, '');
}

function makeCode() {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let suffix = '';
  for (let i = 0; i < 5; i += 1) {
    suffix += alphabet[Math.floor(Math.random() * alphabet.length)];
  }
  return `SX${shanghaiToday().replace(/-/g, '')}${suffix}`;
}

function serialize(row) {
  return {
    id: row.id,
    code: row.code,
    name: row.name,
    phone: row.phone,
    date: row.date,
    time: row.time,
    partySize: row.party_size,
    note: row.note,
    status: row.status,
    createdAt: row.created_at
  };
}

function slotUsage(date) {
  const rows = db
    .prepare(
      "SELECT time, COUNT(*) AS booked, COALESCE(SUM(party_size), 0) AS seats FROM reservations WHERE date = ? AND status = 'confirmed' GROUP BY time"
    )
    .all(date);
  const map = new Map(rows.map((r) => [r.time, { booked: Number(r.booked), seats: Number(r.seats) }]));
  const slots = SLOT_TIMES.map((slot) => {
    const usage = map.get(slot.time) || { booked: 0, seats: 0 };
    const remaining = Math.max(0, SLOT_CAPACITY - usage.booked);
    return {
      time: slot.time,
      period: slot.period,
      capacity: SLOT_CAPACITY,
      booked: usage.booked,
      remaining,
      full: remaining === 0
    };
  });
  const bookedSlots = slots.filter((s) => s.booked > 0).map((s) => s.time);
  return { slots, bookedSlots };
}

function requireAdmin(req, res, next) {
  if (!ADMIN_TOKEN) return next();
  const token = req.get('x-admin-token') || req.query.token;
  if (token === ADMIN_TOKEN) return next();
  return res.status(401).json({ error: '需要管理员口令' });
}

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '32kb' }));

app.get('/api/health', (req, res) => {
  const row = db.prepare('SELECT COUNT(*) AS n FROM reservations').get();
  res.json({ ok: true, service: '蜀香粤味订台服务', reservations: Number(row.n), time: new Date().toISOString() });
});

app.get('/api/reservations/availability', (req, res) => {
  const dateCheck = validateDate(req.query.date);
  if (dateCheck.error) return res.status(400).json({ error: dateCheck.error, fields: { date: dateCheck.error } });
  const date = dateCheck.value;
  const { slots, bookedSlots } = slotUsage(date);
  res.json({
    date,
    capacityPerSlot: SLOT_CAPACITY,
    slots,
    bookedSlots,
    availableSlots: slots.filter((s) => !s.full).map((s) => s.time)
  });
});

app.post('/api/reservations', (req, res) => {
  const body = req.body && typeof req.body === 'object' && !Array.isArray(req.body) ? req.body : {};
  const fields = {};

  const name = String(body.name == null ? '' : body.name).trim();
  if (name.length < 2 || name.length > 30) fields.name = '请填写 2-30 个字符的姓名';

  const phone = normalizePhone(body.phone);
  if (!/^(1[3-9]\d{9}|0\d{9,11})$/.test(phone)) {
    fields.phone = '请填写有效的手机号（11 位）或座机号';
  }

  const dateCheck = validateDate(body.date);
  if (dateCheck.error) fields.date = dateCheck.error;

  const time = String(body.time == null ? '' : body.time).trim();
  if (!SLOT_INDEX.has(time)) fields.time = '请选择可预订的时段';

  const partySize = Number(body.partySize == null ? body.party_size : body.partySize);
  if (!Number.isInteger(partySize) || partySize < 1 || partySize > 20) {
    fields.partySize = '用餐人数需为 1-20 的整数';
  }

  const note = String(body.note == null ? '' : body.note).trim();
  if (note.length > 200) fields.note = '备注不能超过 200 个字符';

  if (Object.keys(fields).length > 0) {
    return res.status(400).json({ error: '预订信息有误，请检查后重试', fields });
  }

  const used = Number(countSlotStmt.get(dateCheck.value, time).n);
  if (used >= SLOT_CAPACITY) {
    return res.status(409).json({
      error: '该时段已订满，请选择其他时段',
      fields: { time: '该时段已订满' }
    });
  }

  const duplicate = duplicateStmt.get(phone, dateCheck.value, time);
  if (duplicate) {
    return res.status(409).json({
      error: `该手机号已预订 ${dateCheck.value} ${time} 的座位（预订号 ${duplicate.code}）`,
      fields: { phone: '同一时段请勿重复预订' }
    });
  }

  const createdAt = new Date().toISOString();
  let code = makeCode();
  let result;
  for (let attempt = 0; attempt < 5; attempt += 1) {
    try {
      result = insertStmt.run(code, name, phone, dateCheck.value, time, partySize, note, createdAt);
      break;
    } catch (err) {
      if (String(err.message).includes('UNIQUE') && attempt < 4) {
        code = makeCode();
        continue;
      }
      throw err;
    }
  }

  const row = byIdStmt.get(Number(result.lastInsertRowid));
  res.status(201).json({ reservation: serialize(row) });
});

app.get('/api/reservations', requireAdmin, (req, res) => {
  const filters = [];
  const params = [];
  if (req.query.date) {
    const dateCheck = validateDate(req.query.date);
    if (dateCheck.error) return res.status(400).json({ error: dateCheck.error, fields: { date: dateCheck.error } });
    filters.push('date = ?');
    params.push(dateCheck.value);
  }
  if (req.query.status) {
    filters.push('status = ?');
    params.push(String(req.query.status));
  }
  const limit = Math.min(Math.max(Number(req.query.limit) || 200, 1), 500);
  const where = filters.length ? `WHERE ${filters.join(' AND ')}` : '';
  const rows = db
    .prepare(`SELECT * FROM reservations ${where} ORDER BY date DESC, time DESC, id DESC LIMIT ?`)
    .all(...params, limit);
  const reservations = rows.map(serialize);
  const guests = reservations.reduce((sum, r) => sum + r.partySize, 0);
  res.json({ total: reservations.length, guests, reservations });
});

app.patch('/api/reservations/:id/cancel', requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) return res.status(400).json({ error: '无效的预订编号' });
  const row = byIdStmt.get(id);
  if (!row) return res.status(404).json({ error: '预订不存在' });
  db.prepare("UPDATE reservations SET status = 'cancelled' WHERE id = ?").run(id);
  res.json({ reservation: serialize(byIdStmt.get(id)) });
});

app.use(express.static(path.join(__dirname, 'public'), { extensions: ['html'] }));

app.use('/api', (req, res) => {
  res.status(404).json({ error: '接口不存在' });
});

app.use((err, req, res, next) => {
  if (err && (err.type === 'entity.parse.failed' || err instanceof SyntaxError)) {
    return res.status(400).json({ error: '请求体不是有效的 JSON' });
  }
  console.error('[server error]', err);
  res.status(500).json({ error: '服务器内部错误' });
});

const server = app.listen(PORT, HOST, () => {
  console.log(`蜀香粤味 server listening on http://${HOST}:${PORT}`);
  console.log(`SQLite database: ${DB_FILE}`);
});

function shutdown(signal) {
  console.log(`收到 ${signal}，正在关闭服务…`);
  server.close(() => {
    try {
      db.close();
    } catch (err) {
      console.error(err);
    }
    process.exit(0);
  });
  setTimeout(() => process.exit(0), 3000).unref();
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
