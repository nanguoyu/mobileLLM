from __future__ import annotations

import csv
import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from sales_analysis import (  # noqa: E402
    analyze,
    analyze_file,
    deduplicate,
    order_revenue_cents,
    read_orders,
    render_report,
    write_totals,
)

HEADER = [
    "order_id",
    "updated_at",
    "country",
    "status",
    "quantity",
    "unit_cents",
    "refund_cents",
]


def write_csv(directory: str, rows: list[list[str]]) -> Path:
    path = Path(directory) / "orders.csv"
    with open(path, "w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(HEADER)
        writer.writerows(rows)
    return path


class AnalysisTests(unittest.TestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.tmp = self._tmp.name

    def tearDown(self) -> None:
        self._tmp.cleanup()

    def test_deduplicate_keeps_latest_updated_at(self) -> None:
        path = write_csv(
            self.tmp,
            [
                ["A", "2026-10-01T10:00:00Z", "AT", "paid", "2", "100", "0"],
                ["A", "2026-10-01T12:00:00Z", "AT", "paid", "5", "100", "0"],
                ["A", "2026-10-01T11:00:00Z", "AT", "paid", "9", "100", "0"],
            ],
        )
        rows = deduplicate(read_orders(path))
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["quantity"], 5)
        self.assertEqual(rows[0]["updated_at"], "2026-10-01T12:00:00Z")

    def test_deduplicate_tie_break_uses_last_input_row(self) -> None:
        path = write_csv(
            self.tmp,
            [
                ["A", "2026-10-01T10:00:00Z", "AT", "paid", "1", "100", "0"],
                ["A", "2026-10-01T10:00:00Z", "AT", "paid", "7", "100", "0"],
            ],
        )
        rows = deduplicate(read_orders(path))
        self.assertEqual(rows[0]["quantity"], 7)

    def test_deduplicate_compares_offsets_in_utc(self) -> None:
        path = write_csv(
            self.tmp,
            [
                ["A", "2026-10-01T10:00:00+02:00", "AT", "paid", "1", "100", "0"],
                ["A", "2026-10-01T09:00:00Z", "AT", "paid", "4", "100", "0"],
            ],
        )
        rows = deduplicate(read_orders(path))
        self.assertEqual(rows[0]["quantity"], 4)

    def test_cancelled_orders_excluded_case_insensitively(self) -> None:
        path = write_csv(
            self.tmp,
            [
                ["A", "2026-10-01T10:00:00Z", "AT", "Cancelled", "2", "100", "0"],
                ["B", "2026-10-01T10:00:00Z", "DE", "CANCELLED", "2", "100", "0"],
                ["C", "2026-10-01T10:00:00Z", "FR", "paid", "2", "100", "0"],
            ],
        )
        totals = analyze_file(path)
        self.assertEqual(totals["order_count"], 1)
        self.assertEqual(totals["revenue_cents"], 200)
        self.assertEqual(totals["by_country"], {"FR": 200})

    def test_latest_status_decides_cancellation(self) -> None:
        path = write_csv(
            self.tmp,
            [
                ["A", "2026-10-01T10:00:00Z", "AT", "paid", "2", "100", "0"],
                ["A", "2026-10-01T12:00:00Z", "AT", "cancelled", "2", "100", "0"],
            ],
        )
        totals = analyze_file(path)
        self.assertEqual(totals["order_count"], 0)
        self.assertEqual(totals["revenue_cents"], 0)
        self.assertEqual(totals["by_country"], {})

    def test_refund_arithmetic(self) -> None:
        row = {"quantity": 3, "unit_cents": 1299, "refund_cents": 100}
        self.assertEqual(order_revenue_cents(row), 3797)
        row = {"quantity": 4, "unit_cents": 225, "refund_cents": 900}
        self.assertEqual(order_revenue_cents(row), 0)

    def test_country_aggregation(self) -> None:
        path = write_csv(
            self.tmp,
            [
                ["A", "2026-10-01T10:00:00Z", "AT", "paid", "2", "1000", "0"],
                ["B", "2026-10-01T10:00:00Z", "DE", "paid", "1", "500", "100"],
                ["C", "2026-10-01T10:00:00Z", "AT", "paid", "1", "250", "50"],
            ],
        )
        totals = analyze_file(path)
        self.assertEqual(totals["by_country"], {"AT": 2200, "DE": 400})
        self.assertEqual(totals["revenue_cents"], 2600)
        self.assertEqual(totals["order_count"], 3)

    def test_totals_json_schema_and_types(self) -> None:
        path = write_csv(
            self.tmp,
            [["A", "2026-10-01T10:00:00Z", "AT", "paid", "2", "1000", "0"]],
        )
        totals = analyze_file(path)
        out = Path(self.tmp) / "totals.json"
        write_totals(totals, out)
        loaded = json.loads(out.read_text(encoding="utf-8"))
        self.assertEqual(set(loaded), {"revenue_cents", "order_count", "by_country"})
        self.assertIs(type(loaded["revenue_cents"]), int)
        self.assertIs(type(loaded["order_count"]), int)
        self.assertIs(type(loaded["by_country"]), dict)
        for country, amount in loaded["by_country"].items():
            self.assertIs(type(country), str)
            self.assertIs(type(amount), int)
        self.assertEqual(loaded["revenue_cents"], 2000)

    def test_report_contains_totals(self) -> None:
        report = render_report(
            {"revenue_cents": 1234, "order_count": 2, "by_country": {"AT": 1234}},
            "orders.csv",
        )
        self.assertIn("1234", report)
        self.assertIn("AT", report)
        self.assertIn("Methodology", report)

    def test_bundled_dataset_golden_values(self) -> None:
        csv_path = ROOT / "orders.csv"
        if not csv_path.exists():
            self.skipTest("bundled orders.csv not present")
        totals = analyze_file(csv_path)
        self.assertEqual(totals["order_count"], 4)
        self.assertEqual(totals["revenue_cents"], 6422)
        self.assertEqual(totals["by_country"], {"AT": 3797, "DE": 1750, "FR": 875})


if __name__ == "__main__":
    unittest.main(verbosity=2)
