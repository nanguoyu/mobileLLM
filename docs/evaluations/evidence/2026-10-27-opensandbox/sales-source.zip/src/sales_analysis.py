"""Reproducible sales analysis for orders.csv.

All money is handled as integer euro cents; no floating point is used.
"""

from __future__ import annotations

import csv
import json
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable, Mapping

REQUIRED_COLUMNS = (
    "order_id",
    "updated_at",
    "country",
    "status",
    "quantity",
    "unit_cents",
    "refund_cents",
)

CANCELLED_STATUSES = frozenset({"cancelled", "canceled"})


def parse_timestamp(value: str) -> datetime:
    """Parse an ISO-8601 timestamp into an aware UTC datetime.

    Accepts a trailing ``Z`` as well as explicit offsets. Naive timestamps are
    interpreted as UTC. Raises ValueError on malformed input.
    """
    text = value.strip()
    if not text:
        raise ValueError("empty updated_at timestamp")
    if text.endswith(("Z", "z")):
        text = text[:-1] + "+00:00"
    parsed = datetime.fromisoformat(text)
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _require_int(value: str, column: str, order_id: str) -> int:
    text = (value or "").strip()
    try:
        number = int(text)
    except ValueError as exc:
        raise ValueError(
            f"order {order_id!r}: column {column!r} is not an integer: {value!r}"
        ) from exc
    if number < 0:
        raise ValueError(f"order {order_id!r}: column {column!r} is negative")
    return number


def read_orders(path: str | Path) -> list[dict]:
    """Read and normalize orders.csv into typed row dictionaries."""
    with open(path, newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        missing = [c for c in REQUIRED_COLUMNS if c not in (reader.fieldnames or [])]
        if missing:
            raise ValueError(f"missing required columns: {', '.join(missing)}")
        rows = []
        for line_no, raw in enumerate(reader, start=2):
            order_id = (raw.get("order_id") or "").strip()
            if not order_id:
                raise ValueError(f"line {line_no}: empty order_id")
            country = (raw.get("country") or "").strip().upper()
            if not country:
                raise ValueError(f"line {line_no}: empty country")
            rows.append(
                {
                    "order_id": order_id,
                    "updated_at": (raw.get("updated_at") or "").strip(),
                    "country": country,
                    "status": (raw.get("status") or "").strip().lower(),
                    "quantity": _require_int(raw.get("quantity"), "quantity", order_id),
                    "unit_cents": _require_int(raw.get("unit_cents"), "unit_cents", order_id),
                    "refund_cents": _require_int(
                        raw.get("refund_cents"), "refund_cents", order_id
                    ),
                    "line_no": line_no,
                }
            )
    return rows


def deduplicate(rows: Iterable[Mapping]) -> list[dict]:
    """Keep one row per order_id: latest updated_at, last input row on ties."""
    latest: dict[str, tuple[datetime, int, dict]] = {}
    for row in rows:
        key = row["order_id"]
        ts = parse_timestamp(row["updated_at"])
        candidate = (ts, int(row.get("line_no", 0)), dict(row))
        current = latest.get(key)
        if current is None or (candidate[0], candidate[1]) >= (current[0], current[1]):
            latest[key] = candidate
    return [latest[key][2] for key in latest]


def is_cancelled(row: Mapping) -> bool:
    return str(row["status"]).strip().lower() in CANCELLED_STATUSES


def order_revenue_cents(row: Mapping) -> int:
    """quantity * unit_cents - refund_cents, in integer euro cents."""
    return int(row["quantity"]) * int(row["unit_cents"]) - int(row["refund_cents"])


def analyze(rows: Iterable[Mapping]) -> dict:
    """Deduplicate, drop cancelled orders, and aggregate totals."""
    kept = deduplicate(rows)
    active = [row for row in kept if not is_cancelled(row)]
    by_country: dict[str, int] = defaultdict(int)
    revenue = 0
    for row in active:
        amount = order_revenue_cents(row)
        revenue += amount
        by_country[row["country"]] += amount
    return {
        "revenue_cents": int(revenue),
        "order_count": int(len(active)),
        "by_country": {country: int(by_country[country]) for country in sorted(by_country)},
    }


def analyze_file(path: str | Path) -> dict:
    return analyze(read_orders(path))


def write_totals(totals: Mapping, path: str | Path) -> None:
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(totals, handle, indent=2, sort_keys=False)
        handle.write("\n")


def render_report(totals: Mapping, source: str) -> str:
    by_country = totals["by_country"]
    lines = [
        "# Sales Analysis Report",
        "",
        f"Source file: `{source}`",
        "",
        "## Methodology",
        "",
        "1. Read `orders.csv` and parse `updated_at` as ISO-8601 (UTC-normalized).",
        "2. Deduplicate by `order_id`, keeping the row with the latest `updated_at`;"
        " on an exact timestamp tie the last row in the file wins.",
        "3. Exclude orders whose `status` is `cancelled` (case-insensitive).",
        "4. Revenue per order = `quantity * unit_cents - refund_cents`, in integer"
        " euro cents. No floating-point arithmetic is used.",
        "5. Aggregate revenue overall and by `country`.",
        "",
        "## Results",
        "",
        f"- Orders counted: **{totals['order_count']}**",
        f"- Total revenue: **{totals['revenue_cents']} cents** "
        f"(EUR {totals['revenue_cents'] / 100:.2f} for display only)",
        "",
        "| Country | Revenue (cents) |",
        "| --- | ---: |",
    ]
    for country, amount in by_country.items():
        lines.append(f"| {country} | {amount} |")
    lines.extend(
        [
            "",
            "## Notes",
            "",
            "- Duplicate rows are resolved before cancellation filtering, so the"
            " latest state of an order decides whether it is excluded.",
            "- `totals.json` is machine-readable and contains integer values only.",
            "- Reproduce with `python3 analyze.py --input orders.csv --json-out"
            " totals.json --report REPORT.md`.",
            "",
        ]
    )
    return "\n".join(lines)
