# Sales Analysis (orders.csv)

Dependency-light Python (standard library only) analysis of `orders.csv`.

## Rules

- Deduplicate by `order_id`, keeping the latest `updated_at` (UTC-normalized;
  exact ties resolved by the last row in the file).
- Exclude orders whose `status` is `cancelled` (case-insensitive).
- Per-order revenue: `quantity * unit_cents - refund_cents`, integer euro cents.
- Output `totals.json` with integer `revenue_cents`, integer `order_count`, and
  `by_country` revenue totals.

## Reproduction (from the project root)

```bash
python3 analyze.py --input orders.csv --json-out totals.json --report REPORT.md
python3 -m unittest discover -s tests -v
```

Requirements: Python 3.9+ (uses `from __future__ import annotations`; developed
and tested with Python 3.11). No third-party packages.

## Files

- `orders.csv` — input data (never modified)
- `analyze.py` — CLI entry point
- `src/sales_analysis.py` — parsing, dedupe, revenue and aggregation logic
- `tests/test_analysis.py` — unit tests
- `totals.json` — generated results
- `REPORT.md` — generated human-readable report
