# Sales Analysis Report

Source file: `orders.csv`

## Methodology

1. Read `orders.csv` and parse `updated_at` as ISO-8601 (UTC-normalized).
2. Deduplicate by `order_id`, keeping the row with the latest `updated_at`; on an exact timestamp tie the last row in the file wins.
3. Exclude orders whose `status` is `cancelled` (case-insensitive).
4. Revenue per order = `quantity * unit_cents - refund_cents`, in integer euro cents. No floating-point arithmetic is used.
5. Aggregate revenue overall and by `country`.

## Results

- Orders counted: **4**
- Total revenue: **6422 cents** (EUR 64.22 for display only)

| Country | Revenue (cents) |
| --- | ---: |
| AT | 3797 |
| DE | 1750 |
| FR | 875 |

## Notes

- Duplicate rows are resolved before cancellation filtering, so the latest state of an order decides whether it is excluded.
- `totals.json` is machine-readable and contains integer values only.
- Reproduce with `python3 analyze.py --input orders.csv --json-out totals.json --report REPORT.md`.
