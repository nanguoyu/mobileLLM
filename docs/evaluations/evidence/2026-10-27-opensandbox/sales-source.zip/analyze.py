#!/usr/bin/env python3
"""CLI entry point for the sales analysis."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))

from sales_analysis import (  # noqa: E402
    analyze_file,
    render_report,
    write_totals,
)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Analyze orders.csv sales data.")
    parser.add_argument("--input", default="orders.csv", help="input CSV path")
    parser.add_argument("--json-out", default="totals.json", help="totals JSON path")
    parser.add_argument("--report", default="REPORT.md", help="markdown report path")
    args = parser.parse_args(argv)

    totals = analyze_file(args.input)
    write_totals(totals, args.json_out)
    Path(args.report).write_text(render_report(totals, args.input), encoding="utf-8")

    print(f"orders counted: {totals['order_count']}")
    print(f"revenue_cents: {totals['revenue_cents']}")
    for country, amount in totals["by_country"].items():
        print(f"  {country}: {amount}")
    print(f"wrote {args.json_out} and {args.report}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
